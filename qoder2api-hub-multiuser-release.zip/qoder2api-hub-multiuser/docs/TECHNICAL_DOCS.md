# Qoder2API-Hub (多租户二改增强版) 技术架构与使用文档

> **版本**：v2.0-MultiUser-Enhanced  
> **协议支持**：OpenAI Chat Completions / Responses API (Codex) / Anthropic Messages (Claude Code)  
> **运行环境**：Python 3.9+（纯标准库实现，**零第三方依赖**）  
> **二改作者**：独立二次开发与增强  

---

## 目录
- [一、项目背景与二改声明](#一项目背景与二改声明)
- [二、核心特性矩阵](#二核心特性矩阵)
- [三、系统架构与设计原理](#三系统架构与设计原理)
  - [1. 数据与安全隔离设计](#1-数据与安全隔离设计)
  - [2. 混合双池自适应路由 (BYOA)](#2-混合双池自适应路由-byoa)
  - [3. 集中式“防漏签”保活调度机制](#3-集中式防漏签保活调度机制)
  - [4. 生产级多层流控与防刷削峰体系](#4-生产级多层流控与防刷削峰体系)
- [四、环境配置与部署指南](#四环境配置与部署指南)
  - [1. 环境变量配置全集](#1-环境变量配置全集)
  - [2. Linux / macOS 运行](#2-linux--macos-运行)
  - [3. Windows 运行](#3-windows-运行)
  - [4. Docker 部署](#4-docker-部署)
  - [5. Systemd 生产服务配置](#5-systemd-生产服务配置)
- [五、客户端快速接入与示例](#五客户端快速接入与示例)
- [六、多用户与管理 REST API 规范](#六多用户与管理-rest-api-规范)
- [七、免责声明与开源协议](#七免责声明与开源协议)

---

## 一、项目背景与二改声明

### 1. 二改初衷
原版 `Qoder2API-Hub` 是一款出色的单机个人网关，但仅支持单管理员单池模式，无法支持团队、社群或多好友共同使用（账号混用、无独立 Key、容易互相打爆或被单人刷干额度）。

本二改版本基于原项目的底层逆向协议与通信底座，进行了**全面的生产级多租户重构**，打造出具备完整用户鉴权、数据隔离、双池路由、全员代签与多维流控防护的共享型 API 网关平台。

### 2. 二改开源声明 (Attribution)
- **底层底座致谢**：核心 Qoder 协议逆向与 COSY 签名算法基于原开源项目 `qoder2api-hub` 及相关社区项目，向原作者致敬。
- **独立二改范围**：
  - `qoder_auth.py`：基于 PBKDF2-HMAC-SHA256 的用户注册、登录、Token 鉴权与会话管理；
  - `qoder_db.py`：SQLite 多租户物理数据层、用量审计模型与状态快照；
  - `qoder_crypto.py`：AES-256-GCM 账号敏感凭证落地加密存储；
  - `qoder_user_pool.py`：私有池优先 + 公共池兜底的双层自适应路由架构；
  - `qoder_limiter.py`：单 Key 活跃并发控制（In-flight Guard）、60 秒滑动窗口 RPM 限制与公共池每日配额隔离；
  - `qoder_proxy.py`：全链路流控中间件集成、管理员全站代签 API 路由；
  - `dashboard.html`：多用户控制台 UI、模型授权选择器、用量卡片、管理员集中签到中心。

---

## 二、核心特性矩阵

| 特性维度 | 原项目 (单机版) | 二改多租户增强版 (本版本) |
| :--- | :--- | :--- |
| **租户模式** | 单管理员，全员共享账号 | **严格物理隔离的多租户 (BYOA 模式)**，支持开放注册 |
| **API Key 体系** | 全局统一 Key 或全局禁用 | **每用户可创建独立 Key**，支持自定义名称与不可逆密保 |
| **模型权限粒度** | 全局统一模型范围 | **每 Key 独立绑定模型白名单**（精确控制访问范围） |
| **账号池体系** | 单一全局账号池 | **私有账号池（自用不限） + 公共账号池（兜底白嫖）** |
| **公共池防刷保护** | 无限额（极易被脚本刷崩） | **每人每日配额硬限制**（超额自动拦截并引导自绑账号） |
| **流控削峰机制** | 无 Key 级流控 | **单 Key 活跃并发控制 (In-flight) + 60s 滑动窗口 RPM 限制** |
| **签到福利保障** | 仅单号手动或定时巡检 | **后台自动调度 + 管理员全站一键代签**（防普通用户漏签） |
| **依赖生态** | 零第三方依赖 | **保持纯 Python 3.9+ 标准库**（零外部 pip 依赖） |

---

## 三、系统架构与设计原理

### 1. 数据与安全隔离设计
系统采用 SQLite 作为持久化数据仓库，通过四张核心表与加盐哈希构建无碰撞安全体系：

```
[ users ] (用户表)
   ├── id (UUID 主键)
   ├── username (唯一)
   ├── password_hash (PBKDF2-HMAC-SHA256 100,000次迭代 + 随机Salt)
   └── is_admin (首个注册用户自动成为管理员)
   
[ qoder_accounts ] (Qoder 账号表)
   ├── uid (账号唯一标识)
   ├── user_id (NULL 代表公共池，UUID 代表用户私有账号)
   ├── access_token (AES-256-GCM 加密落盘)
   └── credits / last_checkin (实时状态)

[ api_keys ] (API 密钥表)
   ├── user_id (外键关联用户)
   ├── key_hash (SHA256 哈希存储，明文仅生成时展示一次)
   └── models (JSON 数组，该 Key 允许调用的模型白名单)

[ usage_log ] (审计日志表)
   ├── user_id / api_key_id / account_source (标记 private 还是 public)
   └── prompt_tokens / completion_tokens / credits / elapsed_ms / ttft_ms
```

### 2. 混合双池自适应路由 (BYOA)
请求到达网关后，系统通过三级漏斗自动路由至最合适账号：

```
客户端请求 (携带用户 API Key)
       │
       ▼
[鉴权与流控] 校验 Key 有效性、RPM 限速、活跃并发数、模型白名单
       │
       ▼
[私有账号池] 检索该用户个人绑定的可用私有 Qoder 账号
  ├── 存在可用私有号 ──────► 走私有账号池调用 (不限额度，优先消耗个人资产)
  └── 无私有号 / 全冷却
       │
       ▼
[公共池配额检查] 校验该用户今日已从公共池消耗的 Credits
  ├── 达到每日限额 (如 100) ─► 429 拦截 (提示"今日公共额度已用尽，请绑定私有账号")
  └── 额度未超限
       │
       ▼
[公共池调度] 从全站公共账号池中轮询选号并完成推理
```

### 3. 集中式“防漏签”保活调度机制
针对大量普通用户日常不登录、忘记打卡签到导致官方每日 100 Credits 额度流失的问题，系统设计了双重闭环：
- **后台守护线程巡检**：`Scheduler` 自动跨租户扫描内存中的全量有效账号，按既定排程批量领取每日奖励与 Pro 福利；
- **管理员一键全员代签**：管理员可直接在 Web 控制台触发 `/api/admin/accounts/checkin`，后台使用高并发线程池为全站账号批量完成签到闭环，实时写回数据库并生成审计流水。

### 4. 生产级多层流控与防刷削峰体系
- **In-flight 活跃并发限制**：精准跟踪每个 Key 当前“正在传输中（尤其是长文本流式输出）”的连接数。只有在首包返回且流式完整关闭后，才在 `finally` 块中原子释放名额，彻底防止多开脚本瞬间把官方账号打进高负载熔断。
- **60 秒滑动窗口 RPM 限制**：采用单调时间戳队列记录请求历史，自动剥离过期请求并精确计算超限客户端应等待的重试秒数，携带 HTTP `Retry-After` 标准响应头。

---

## 四、环境配置与部署指南

### 1. 环境变量配置全集

| 环境变量 | 默认值 | 作用与说明 |
| :--- | :--- | :--- |
| `QD_MULTIUSER_DB` | `./data/multiuser.db` | **多租户开关**。指向 SQLite 数据库文件即可开启多租户模式 |
| `QD_MAX_CONCURRENCY_PER_KEY` | `3` | 单个 API Key 最大允许并发处理的请求数（`0` 为不限） |
| `QD_MAX_RPM_PER_KEY` | `30` | 单个 API Key 每分钟最大请求次数（`0` 为不限） |
| `QD_PUBLIC_POOL_DAILY_LIMIT` | `100.0` | 普通用户每日从公共池可消耗的最大 Credits（`-1` 不限，`0` 禁用公共池） |
| `QD_CHECKIN_CONCURRENCY` | `3` | 集中签到与后台巡检时的最大并发线程数（1–8） |
| `PORT` | `8790` | 网关监听端口 |
| `HOST` | `127.0.0.1` | 监听地址（若对外提供服务需设为 `0.0.0.0`） |

### 2. Linux / macOS 运行

```bash
# 1. 赋予执行权限
chmod +x *.sh

# 2. 启动多用户网关服务
QD_MULTIUSER_DB=./data/multiuser.db ./start-qoder-proxy.sh

# 3. 停止服务
./stop-qoder-proxy.sh
```

### 3. Windows 运行

在 PowerShell 或命令提示符中执行：
```bat
set QD_MULTIUSER_DB=.\data\multiuser.db
python qoder_proxy.py --port 8790
```

### 4. Docker 部署

```yaml
version: '3.8'

services:
  qoder-hub:
    image: python:3.10-slim
    container_name: qoder2api-hub
    restart: always
    working_dir: /app
    volumes:
      - ./:/app
      - ./data:/app/data
    environment:
      - QD_MULTIUSER_DB=/app/data/multiuser.db
      - QD_MAX_CONCURRENCY_PER_KEY=3
      - QD_MAX_RPM_PER_KEY=30
      - QD_PUBLIC_POOL_DAILY_LIMIT=100.0
      - HOST=0.0.0.0
      - PORT=8790
    ports:
      - "8790:8790"
    command: python qoder_proxy.py --host 0.0.0.0 --port 8790
```

### 5. Systemd 生产服务配置 (Linux VPS)

创建 `/etc/systemd/system/qoder-hub.service`：
```ini
[Unit]
Description=Qoder2API Hub Multi-User Gateway
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/qoder2api-hub
Environment="QD_MULTIUSER_DB=/opt/qoder2api-hub/data/multiuser.db"
Environment="HOST=0.0.0.0"
Environment="PORT=8790"
ExecStart=/usr/bin/python3 /opt/qoder2api-hub/qoder_proxy.py --host 0.0.0.0 --port 8790
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
```
启动并设为开机自启：
```bash
systemctl daemon-reload
systemctl enable --now qoder-hub
```

---

## 五、客户端快速接入与示例

### 1. cURL 示例
```bash
curl http://127.0.0.1:8790/v1/chat/completions \
  -H "Authorization: Bearer qd-xxxxxxxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d '{
    "model": "Qwen3.8-Flash",
    "messages": [
      {"role": "user", "content": "你好，请写一段冒泡排序"}
    ],
    "stream": true
  }'
```

### 2. 常用第三方客户端配置表

| 客户端工具 | API Base URL | API Key | 协议类型 |
| :--- | :--- | :--- | :--- |
| **Cherry Studio** | `http://<IP>:8790/v1` | 平台生成的 `qd-***` Key | OpenAI 兼容 |
| **NextChat / 各种 Web UI** | `http://<IP>:8790/v1` | 平台生成的 `qd-***` Key | OpenAI 兼容 |
| **沉浸式翻译** | `http://<IP>:8790/v1` | 平台生成的 `qd-***` Key | OpenAI 兼容 |
| **Cursor / VSCode 插件** | `http://<IP>:8790/v1` | 平台生成的 `qd-***` Key | OpenAI 兼容 |
| **Claude Code** | `http://<IP>:8790` (不带/v1) | 平台生成的 `qd-***` Key | Anthropic Messages |

---

## 六、多用户与管理 REST API 规范

- **`POST /api/register`**：注册新用户（首个注册账号自动提升为超级管理员）。
- **`POST /api/login`**：登录并获取 Bearer Session Token。
- **`GET /api/me`**：获取当前登录用户信息、角色与状态。
- **`GET /api/keys`**：获取当前用户的所有 API Key 列表。
- **`POST /api/keys`**：创建新的 API Key（可选指定允许的模型白名单数组）。
- **`DELETE /api/keys/<id>`**：删除指定 API Key。
- **`GET /api/accounts`**：获取当前用户可见的账号列表（私有 + 公共池）。
- **`POST /api/admin/accounts/checkin`** *(管理员专用)*：为全站所有账号或指定账号集中执行每日签到并入库。
- **`POST /api/admin/accounts/travel`** *(管理员专用)*：为全站所有账号集中领取 Pro 福利包。
- **`POST /api/admin/accounts/credits/fetch`** *(管理员专用)*：全站账号额度批量刷新。

---

## 七、免责声明与开源协议

1. 本项目为非官方自托管网关，仅供技术研究、协议逆向学习与个人自动化运维交流使用。
2. 本项目不内置、不提供、不销售任何 Qoder 官方账号或商用额度；使用本项目时请严格遵守 Qoder 官方的服务条款及相关法规。
3. 本项目基于 [MIT License](LICENSE) 开源发布。
