"""qoder_limiter.py — 速率限制、并发控制与公共池每日配额防护

提供：
1. Key 级并发数限制（In-flight Concurrency Guard）：防单 Key 打爆网关与官方账号
2. Key 级请求速率限制（RPM - Requests Per Minute 滑动窗口）：平滑瞬时峰值
3. 用户级公共池每日配额限制（Public Pool Daily Credits Limit）：防公共账号被个别用户耗尽
"""
import os
import time
import threading
from collections import deque
import qoder_db


def _get_env_int(key: str, default: int) -> int:
    try:
        val = os.environ.get(key)
        return int(val) if val is not None else default
    except Exception:
        return default


def _get_env_float(key: str, default: float) -> float:
    try:
        val = os.environ.get(key)
        return float(val) if val is not None else default
    except Exception:
        return default


class RateLimiter:
    def __init__(self):
        self._lock = threading.Lock()
        # key_id -> 当前并发数 int
        self._active_concurrency: dict[str, int] = {}
        # key_id -> deque([ts1, ts2, ...]) 最近 60 秒内的请求时间戳
        self._rpm_history: dict[str, deque] = {}

    @property
    def max_concurrency(self) -> int:
        """单 Key 最大并发连接数（0 表示不限制，默认 3）"""
        return _get_env_int("QD_MAX_CONCURRENCY_PER_KEY", 3)

    @property
    def max_rpm(self) -> int:
        """单 Key 每分钟最大请求数（0 表示不限制，默认 30）"""
        return _get_env_int("QD_MAX_RPM_PER_KEY", 30)

    @property
    def public_pool_daily_limit(self) -> float:
        """每个普通用户每天从公共池最多消耗的 Credits（-1 表示不限，0 表示禁用公共池，默认 100.0）"""
        return _get_env_float("QD_PUBLIC_POOL_DAILY_LIMIT", 100.0)

    def acquire(self, key_id: str) -> tuple[bool, str, int, int]:
        """
        请求进入前检查 RPM 与并发。
        若通过，并发数+1，记录 RPM 时间戳；
        若超限，返回 (False, error_msg, http_status, retry_after_seconds)。
        """
        if not key_id:
            return True, "", 200, 0

        now = time.time()
        max_c = self.max_concurrency
        max_rpm = self.max_rpm

        with self._lock:
            # 1. 检查 RPM
            if max_rpm > 0:
                history = self._rpm_history.setdefault(key_id, deque())
                # 剔除 60 秒以前的请求
                while history and history[0] <= now - 60.0:
                    history.popleft()
                if len(history) >= max_rpm:
                    # 计算最早的一个请求何时过期
                    earliest = history[0]
                    retry_after = max(1, int(60.0 - (now - earliest)) + 1)
                    return (
                        False,
                        f"请求速率超限：该 API Key 限制每分钟最多 {max_rpm} 次请求 (RPM Limit)。请在 {retry_after} 秒后重试。",
                        429,
                        retry_after,
                    )

            # 2. 检查并发
            if max_c > 0:
                curr_c = self._active_concurrency.get(key_id, 0)
                if curr_c >= max_c:
                    return (
                        False,
                        f"并发连接超限：该 API Key 最大允许 {max_c} 个同时在飞的并发请求，当前已有 {curr_c} 个请求正在处理。",
                        429,
                        2,
                    )
                self._active_concurrency[key_id] = curr_c + 1
            else:
                self._active_concurrency[key_id] = self._active_concurrency.get(key_id, 0) + 1

            # 3. 记录本次请求时间戳
            if max_rpm > 0:
                self._rpm_history[key_id].append(now)

            return True, "", 200, 0

    def release(self, key_id: str) -> None:
        """请求结束后（流式结束/异常断开/完成）原子释放并发数。"""
        if not key_id:
            return
        with self._lock:
            curr = self._active_concurrency.get(key_id, 0)
            if curr <= 1:
                self._active_concurrency.pop(key_id, None)
            else:
                self._active_concurrency[key_id] = curr - 1

    def get_key_concurrency(self, key_id: str) -> int:
        """获取指定 Key 当前的活跃并发数。"""
        with self._lock:
            return self._active_concurrency.get(key_id, 0)

    def check_public_pool_quota(self, user_id: str, is_admin: bool = False) -> tuple[bool, float, float]:
        """
        检查用户今日公共池配额。
        返回 (is_allowed, used_today, daily_limit)。
        """
        daily_limit = self.public_pool_daily_limit
        # 不设限或管理员用户直接放行
        if daily_limit < 0 or is_admin:
            return True, 0.0, daily_limit

        used_today = qoder_db.user_public_credits_today(user_id)
        if daily_limit == 0:
            # 0 表示不允许普通用户使用公共池
            return False, used_today, 0.0

        if used_today >= daily_limit:
            return False, used_today, daily_limit

        return True, used_today, daily_limit


# 全局单例
LIMITER = RateLimiter()
