"""qoder_user_pool.py — 按用户隔离的 Qoder 账号池

每个用户有独立的账号集合，选号时优先用私有账号，全部不可用时落到公共池。
所有账号从 SQLite 加载，状态（冷却、余额）在内存中维护，与原有 AccountPool 逻辑复用。
"""
import os
import threading
import time
import json

import qoder_db
import qoder_crypto
from qoder_accounts import Account, REALM_CONFIGS, get_realm_config

_lock = threading.RLock()

# user_id → [Account, ...]（内存缓存，定期从 DB 同步）
_user_pools: dict[str, list] = {}
# 公共池（user_id=None 的账号）
_public_pool: list = []
# 上次同步时间
_last_sync: float = 0.0
_SYNC_INTERVAL = 30.0   # 秒


# ── 内部工具 ──────────────────────────────────────────────────────────────────

def _db_row_to_account(row: dict) -> Account | None:
    """将数据库行转换为 Account 对象。"""
    try:
        access_token  = qoder_crypto.decrypt_token(row.get("access_token_enc") or "")
        refresh_token = qoder_crypto.decrypt_token(row.get("refresh_token_enc") or "")
        personal_token = qoder_crypto.decrypt_token(row.get("personal_token_enc") or "")
        acc_credits = row.get("credits")
        acc_dir = "./accounts"
        json_file = os.path.join(acc_dir, f"{row['uid']}.json")
        if os.path.isfile(json_file):
            try:
                with open(json_file, "r", encoding="utf-8") as jf:
                    jd = json.load(jf)
                    if isinstance(jd.get("credits"), dict):
                        acc_credits = jd["credits"]
            except Exception:
                pass
        data = {
            "uid":           row["uid"],
            "realm":         row.get("realm") or "cn",
            "nickname":      row.get("nickname") or "",
            "note":          row.get("note") or "",
            "accessToken":   access_token,
            "refreshToken":  refresh_token,
            "personalToken": personal_token,
            "expiresAt":     row.get("expires_at"),
            "enabled":       bool(row.get("enabled", 1)),
            "source":        row.get("source") or "oauth",
            "plan":          row.get("plan") or "",
            "credits":       acc_credits,
            "lastCheckin":   row.get("last_checkin") or None,
            "addedAt":       time.time(),
        }
        acc = Account(data)
        # 挂载 DB 元数据，供保存时使用
        acc._db_user_id = row.get("user_id")
        return acc
    except Exception as exc:
        print(f"[user-pool] account {row.get('uid')} load error: {exc}")
        return None


def _sync_from_db(force: bool = False) -> None:
    """从数据库重新加载所有账号到内存。"""
    global _last_sync, _user_pools, _public_pool
    now = time.time()
    if not force and (now - _last_sync) < _SYNC_INTERVAL:
        return
    with _lock:
        rows = qoder_db.list_qoder_accounts(user_id="NOFILTER")
        new_user_pools: dict[str, list] = {}
        new_public: list = []
        for row in rows:
            if not row.get("enabled", 1):
                continue
            acc = _db_row_to_account(row)
            if acc is None:
                continue
            uid = row.get("user_id")
            if uid is None:
                new_public.append(acc)
            else:
                new_user_pools.setdefault(uid, []).append(acc)
        # 合并内存状态（保留冷却、余额等运行时字段）
        _user_pools  = _merge_pool_state(_user_pools, new_user_pools)
        _public_pool = _merge_list_state(_public_pool, new_public)
        _last_sync = now


def _merge_pool_state(old: dict, new: dict) -> dict:
    result = {}
    for uid, accs in new.items():
        old_list = old.get(uid, [])
        result[uid] = _merge_list_state(old_list, accs)
    return result


def _merge_list_state(old_list: list, new_list: list) -> list:
    """新账号列表中，若旧列表有同 uid 的，保留其运行时状态。"""
    old_map = {a.uid: a for a in old_list}
    merged = []
    for new_acc in new_list:
        old_acc = old_map.get(new_acc.uid)
        if old_acc:
            # 保留冷却/余额等运行时状态，更新 token
            old_acc.access_token  = new_acc.access_token
            old_acc.refresh_token = new_acc.refresh_token
            old_acc.enabled       = new_acc.enabled
            merged.append(old_acc)
        else:
            merged.append(new_acc)
    return merged


# ── 选号 ─────────────────────────────────────────────────────────────────────

def _candidate_accounts(user_id: str, realm: str | None = None) -> list:
    """返回该用户可用的候选账号列表（私有优先，公共兜底）。"""
    _sync_from_db()
    with _lock:
        private = list(_user_pools.get(user_id, []))
        public  = list(_public_pool)

    def ready(acc) -> bool:
        if not acc.enabled:
            return False
        if realm and acc.realm != realm:
            return False
        return acc.ready()

    private_ready = [a for a in private if ready(a)]
    if private_ready:
        return private_ready, "private"
    # 回落公共池
    public_ready = [a for a in public if ready(a)]
    return public_ready, "public"


def pick_account(user_id: str, realm: str | None = None,
                 model: str | None = None):
    """
    为指定用户选一个可用账号。
    返回 (Account, source) 或 (None, None)。
    source: 'private' | 'public'
    """
    candidates, source = _candidate_accounts(user_id, realm)
    if not candidates:
        return None, None
    # 简单轮询（保持与原有调度一致的风格）
    return candidates[0], source


# ── 账号添加/删除 ─────────────────────────────────────────────────────────────

def add_account_from_oauth(user_id: str | None,
                           account_data: dict) -> dict:
    """
    将 OAuth 授权完成的账号数据写入 DB 并刷新内存池。
    user_id=None 表示添加到公共池（管理员操作）。
    account_data 为 Account.__init__ 接受的 dict 格式（含明文 token）。
    """
    enc_access  = qoder_crypto.encrypt_token(account_data.get("accessToken") or "")
    enc_refresh = qoder_crypto.encrypt_token(account_data.get("refreshToken") or "")
    enc_pat     = qoder_crypto.encrypt_token(account_data.get("personalToken") or "")
    row = qoder_db.upsert_qoder_account(
        uid               = account_data["uid"],
        user_id           = user_id,
        realm             = account_data.get("realm") or "cn",
        access_token_enc  = enc_access,
        refresh_token_enc = enc_refresh,
        personal_token_enc= enc_pat,
        nickname          = account_data.get("nickname") or "",
        note              = account_data.get("note") or "",
        source            = account_data.get("source") or "oauth",
        credits           = account_data.get("credits"),
        plan              = account_data.get("plan") or "",
        expires_at        = account_data.get("expiresAt"),
    )
    _sync_from_db(force=True)
    # 异步为新账号查询初始额度与套餐，立即填充余额数据
    def _init_fetch():
        try:
            time.sleep(0.3)
            acc = get_in_memory_account(account_data["uid"])
            if acc:
                acc.fetch_credits()
                acc.fetch_plan()
                save_account_state(acc)
        except Exception:
            pass
    threading.Thread(target=_init_fetch, daemon=True).start()
    return row


def update_account_tokens(uid: str,
                           access_token: str = "",
                           refresh_token: str = "",
                           personal_token: str = "") -> None:
    """刷新 Token 后更新 DB 中的加密存储。"""
    kwargs = {}
    if access_token:
        kwargs["access_token_enc"]  = qoder_crypto.encrypt_token(access_token)
    if refresh_token:
        kwargs["refresh_token_enc"] = qoder_crypto.encrypt_token(refresh_token)
    if personal_token:
        kwargs["personal_token_enc"]= qoder_crypto.encrypt_token(personal_token)
    if kwargs:
        qoder_db.update_qoder_account(uid, **kwargs)
        _sync_from_db(force=True)


def remove_account(uid: str, user_id: str | None = None,
                   is_admin: bool = False) -> bool:
    """
    删除账号。普通用户只能删自己的，管理员可删公共池账号。
    """
    row = qoder_db.get_qoder_account(uid)
    if not row:
        return False
    if not is_admin:
        if row.get("user_id") != user_id:
            return False
    ok = qoder_db.delete_qoder_account(uid)
    if ok:
        _sync_from_db(force=True)
    return ok


# ── 账号状态回写 ──────────────────────────────────────────────────────────────

def save_account_state(acc: Account) -> None:
    """将 Account 的余额、签到等状态写回 DB（由调度器与签到接口调用）。"""
    kwargs = {}
    if acc.credits is not None:
        c = acc.credits
        if isinstance(c, dict):
            c = c.get("remain_effective") if c.get("remain_effective") is not None else c.get("remain")
        try:
            kwargs["credits"] = float(c) if c is not None else None
        except (ValueError, TypeError):
            pass
    elif getattr(acc, "credits_degraded", None):
        kwargs["credits"] = 0.0
    if acc.plan:
        kwargs["plan"] = acc.plan
    if acc.last_checkin:
        kwargs["last_checkin"] = str(acc.last_checkin)
    if kwargs:
        qoder_db.update_qoder_account(acc.uid, **kwargs)


def get_in_memory_account(uid: str) -> Account | None:
    """从内存池中查找账号（不触发 DB 查询）。"""
    with _lock:
        for accs in _user_pools.values():
            for a in accs:
                if a.uid == uid:
                    return a
        for a in _public_pool:
            if a.uid == uid:
                return a
    return None


def all_in_memory_accounts() -> list[Account]:
    """返回所有内存中的 Account 对象（含私有与公共）。"""
    _sync_from_db()
    with _lock:
        seen = set()
        accs = []
        for user_accs in _user_pools.values():
            for a in user_accs:
                if a.uid not in seen:
                    seen.add(a.uid)
                    accs.append(a)
        for a in _public_pool:
            if a.uid not in seen:
                seen.add(a.uid)
                accs.append(a)
        return accs


# ── 视图 ─────────────────────────────────────────────────────────────────────

def account_views_for_user(user_id: str) -> list[dict]:
    """返回用户可见的账号视图（私有 + 公共，不含 Token 明文）。"""
    _sync_from_db()
    with _lock:
        private = list(_user_pools.get(user_id, []))
        public  = list(_public_pool)
    result = []
    for acc in private:
        result.append(_account_view(acc, source="private"))
    for acc in public:
        result.append(_account_view(acc, source="public"))
    return result


def account_views_admin() -> list[dict]:
    """管理员视图：所有账号（含归属用户与用户名）。"""
    _sync_from_db()
    users_map = {}
    try:
        users = qoder_db.list_users()
        users_map = {u["id"]: u["username"] for u in users}
    except Exception:
        pass
    with _lock:
        all_rows = []
        for uid, accs in _user_pools.items():
            for acc in accs:
                v = _account_view(acc, source="private")
                v["owner_user_id"] = uid
                v["owner_username"] = users_map.get(uid, "")
                all_rows.append(v)
        for acc in _public_pool:
            v = _account_view(acc, source="public")
            v["owner_user_id"] = None
            v["owner_username"] = "公共池"
            all_rows.append(v)
    return all_rows


def _account_view(acc: Account, source: str = "private") -> dict:
    checked_in_today = str(acc.last_checkin or "").startswith(time.strftime("%Y-%m-%d"))
    c = acc.credits
    credits_num = c.get("remain") if isinstance(c, dict) else c
    if credits_num is None and getattr(acc, "credits_degraded", None):
        credits_num = 0
    return {
        "uid":                 acc.uid,
        "nickname":            acc.nickname,
        "note":                acc.note,
        "realm":               acc.realm,
        "enabled":             acc.enabled,
        "credits":             acc.credits,
        "credits_num":         credits_num,
        "creditsDegraded":     getattr(acc, "credits_degraded", None),
        "creditsUpdatedAt":    (acc.credits.get("updated_at") if isinstance(acc.credits, dict) else None),
        "creditsUpdatedIso":   (acc.credits.get("updated_iso") if isinstance(acc.credits, dict) else None),
        "creditsRefreshState": getattr(acc, "credits_refresh_state", "idle"),
        "creditsRefreshError": getattr(acc, "credits_refresh_error", ""),
        "plan":                acc.plan,
        "source":              source,
        "last_checkin":        acc.last_checkin,
        "lastCheckinDate":     str(acc.last_checkin or "")[:10],
        "checkedInToday":      checked_in_today,
        "ready":               acc.ready() if acc.enabled else False,
    }


def force_sync() -> None:
    """强制从 DB 重新加载（账号变更后调用）。"""
    _sync_from_db(force=True)


# ── UserAccountPool：AccountPool 兼容适配器 ───────────────────────────────────

class _NoopAffinity:
    """简单的会话亲和实现（不依赖 SessionAffinity 类）。"""
    def __init__(self):
        self._map = {}
        self._lock = threading.Lock()

    def get(self, key):
        with self._lock:
            return self._map.get(key)

    def bind(self, key, uid):
        with self._lock:
            self._map[key] = uid

    def unbind(self, key):
        with self._lock:
            self._map.pop(key, None)


class UserAccountPool:
    """
    针对单个用户的账号池适配器。
    接口与 qoder_accounts.AccountPool 兼容（open_upstream 所需的子集）。
    优先从用户私有账号中选号，全部不可用时回落公共池。
    """

    def __init__(self, user_id: str, is_admin: bool = False):
        self.user_id = user_id
        self.is_admin = is_admin
        self.affinity = _NoopAffinity()
        self._expiry_weights = {}
        self._lock = threading.RLock()
        self.last_quota_exceeded_msg = ""

    @property
    def accounts(self) -> list:
        """返回该用户可用的所有账号（私有 + 公共）。"""
        _sync_from_db()
        with _lock:
            private = list(_user_pools.get(self.user_id, []))
            public  = list(_public_pool)
        return private + public

    def get(self, uid: str):
        for acc in self.accounts:
            if acc.uid == uid:
                return acc
        return None

    def count_ready(self, realm=None, model=None) -> int:
        snapshot = [a for a in self.accounts if not realm or a.realm == realm]
        return sum(1 for a in snapshot
                   if a.enabled and a.access_token and a.ready(model=model))

    def pick(self, realm=None, exclude=None, model=None):
        """优先私有账号，再公共账号，简单轮询。"""
        exclude = exclude or set()
        _sync_from_db()
        with _lock:
            private = list(_user_pools.get(self.user_id, []))
            public  = list(_public_pool)

        def _ready(a):
            if a.uid in exclude or not a.enabled or not a.access_token:
                return False
            if realm and a.realm != realm:
                return False
            return a.ready(model=model)

        candidates = [a for a in private if _ready(a)]
        source = "private"
        if not candidates:
            from qoder_limiter import LIMITER
            allowed, used, limit = LIMITER.check_public_pool_quota(self.user_id, is_admin=self.is_admin)
            if not allowed:
                self.last_quota_exceeded_msg = (
                    f"公共池每日配额已用尽 (今日已用 {used:.1f}/{limit:.0f} Credits)，请添加您的个人 Qoder 账号继续使用"
                )
                return None
            candidates = [a for a in public if _ready(a)]
            source = "public"
        if not candidates:
            return None
        # 轮询（简单：按 tried 集合排序，取第一个未用过的）
        acc = candidates[0]
        acc._mt_source = source
        return acc

    def pick_for_session(self, realm=None, session_key=None,
                         exclude=None, model=None):
        exclude = exclude or set()
        if session_key:
            bound_uid = self.affinity.get(session_key)
            if bound_uid and bound_uid not in exclude:
                account = self.get(bound_uid)
                if account and (not realm or account.realm == realm) \
                        and account.ready(model=model):
                    return account
                self.affinity.unbind(session_key)
        account = self.pick(realm=realm, exclude=exclude, model=model)
        if account and session_key:
            self.affinity.bind(session_key, account.uid)
        return account

    def representative(self, realm=None):
        return self.pick(realm=realm)

