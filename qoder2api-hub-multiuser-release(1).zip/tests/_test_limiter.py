"""测试速率限制、并发限制与公共池每日配额"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import time
from collections import deque
import qoder_limiter
from qoder_limiter import LIMITER

# 1. 测试并发限制
k1 = "test-key-1"
ok1, _, _, _ = LIMITER.acquire(k1)
assert ok1, "第 1 次获取应成功"
ok2, _, _, _ = LIMITER.acquire(k1)
assert ok2, "第 2 次获取应成功"
ok3, _, _, _ = LIMITER.acquire(k1)
assert ok3, "第 3 次获取应成功"
assert LIMITER.get_key_concurrency(k1) == 3

# 第 4 次并发应该被拒绝
ok4, msg4, status4, _ = LIMITER.acquire(k1)
assert not ok4, "超出并发限制应被拒绝"
assert status4 == 429
assert "并发连接超限" in msg4

# 释放一个
LIMITER.release(k1)
assert LIMITER.get_key_concurrency(k1) == 2
# 现在可以重新获取
ok5, _, _, _ = LIMITER.acquire(k1)
assert ok5, "释放后应可再次获取"

LIMITER.release(k1)
LIMITER.release(k1)
LIMITER.release(k1)
assert LIMITER.get_key_concurrency(k1) == 0
print("✓ 并发限制测试通过")

# 2. 测试 RPM 限制
k2 = "test-key-rpm"
LIMITER._rpm_history[k2] = deque([time.time()] * LIMITER.max_rpm)
ok_rpm, msg_rpm, status_rpm, retry_after = LIMITER.acquire(k2)
assert not ok_rpm, "超出 RPM 应被拦截"
assert status_rpm == 429
assert "速率超限" in msg_rpm
assert retry_after > 0
print("✓ RPM 速率限制测试通过")

# 3. 测试公共池限额
import qoder_db
qoder_db.init("./data/multiuser.db")
ok_admin, _, _ = LIMITER.check_public_pool_quota("admin-user-id", is_admin=True)
assert ok_admin, "管理员应不限额"

ok_user, used, limit = LIMITER.check_public_pool_quota("test-user-id", is_admin=False)
assert ok_user, "新用户未消耗前应放行"
assert limit == 100.0
print("✓ 公共池每日配额逻辑测试通过")

print("ALL LIMITER TESTS PASSED!")
