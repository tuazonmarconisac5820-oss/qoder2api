import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import unittest
import qoder_openai

class TestOpenAIOAuth(unittest.TestCase):
    def test_poll_unknown_state(self):
        res = qoder_openai.poll_openai_login("oa-nonexistent-state")
        self.assertEqual(res["status"], "unknown")
        
    def test_oauth_memory_structure(self):
        with qoder_openai._login_lock:
            qoder_openai._openai_logins["oa-test-123"] = {
                "created": 100000.0,  # expired
                "device_code": "dummy",
                "user_code": "ABCD-1234",
                "interval": 5,
                "expires_in": 900
            }
        res = qoder_openai.poll_openai_login("oa-test-123")
        self.assertEqual(res["status"], "expired")

if __name__ == "__main__":
    unittest.main()
