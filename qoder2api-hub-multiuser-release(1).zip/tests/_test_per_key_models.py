"""Per-key model allowlists: persistence, panel API and live HTTP enforcement."""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _suite_head import *  # noqa: F401,F403

P, A = bootstrap()
import http.client
import http.server
import threading
import qoder_settings as S

declare_suite(__file__, ["qoder_proxy.py", "qoder_settings.py", "dashboard.html"])

D = tempfile.mkdtemp(prefix="qd-key-models-")
old = {name: getattr(P, name) for name in
       ("ACCOUNTS_DIR", "API_KEY", "API_KEY_FILE_SET", "POOL", "open_upstream")}
P.ACCOUNTS_DIR = D
P.API_KEY = ""
P.API_KEY_FILE_SET = False
P.POOL = None
outbound = []


def fake_upstream(payload, **kwargs):
    outbound.append({"payload": dict(payload), "kwargs": kwargs})
    raise RuntimeError("allowlist test: request reached upstream")


def request(method, path, body=None, key=None, panel=None):
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=15)
    headers = {}
    if key:
        headers["Authorization"] = "Bearer " + key
    if panel:
        headers["X-Panel-Token"] = panel
    raw = None
    if body is not None:
        raw = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    try:
        conn.request(method, path, body=raw, headers=headers)
        response = conn.getresponse()
        text = response.read().decode("utf-8", "replace")
        try:
            return response.status, json.loads(text)
        except ValueError:
            return response.status, text
    finally:
        conn.close()


def keepalive_models():
    """Use the same handler for two different credentials on one connection."""
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=15)
    replies = []
    try:
        for key in ("flash-secret", "open-secret"):
            conn.request("GET", "/v1/models",
                         headers={"Authorization": "Bearer " + key})
            response = conn.getresponse()
            replies.append(json.loads(response.read().decode("utf-8")))
        return replies
    finally:
        conn.close()


def save_keys(rows):
    return request("POST", "/settings/save", {"api_keys": rows}, panel=TOKEN)


def models(key):
    return request("GET", "/v1/models", key=key)


def inference(path, model, key, tools=False):
    body = {"model": model, "messages": [{"role": "user", "content": "hi"}]}
    if path == "/v1/messages":
        body["max_tokens"] = 16
    if tools:
        body["tools"] = [{"type": "web_search"}]
    before = len(outbound)
    status, reply = request("POST", path, body, key=key)
    return status, reply, len(outbound) - before


P.open_upstream = fake_upstream
S.set_api_keys(D, [
    {"id": "flash", "name": "Flash only", "key": "flash-secret",
     "models": ["qwen3.8-flash"], "note": "keep this note"},
    {"id": "claude", "name": "Claude only", "key": "claude-secret",
     "models": ["claude-*"]},
    {"id": "open", "name": "Unrestricted", "key": "open-secret"},
])
TOKEN = P.PANEL.create()
P.fetch_models = lambda realm=None: [
    ("qwen-flash", {"name": "Qwen3.8-Flash", "aliases": ["Qwen-Flash"]}),
    ("claude-sonnet", {"name": "Claude-Sonnet"}),
]
P.fetch_models_merged = lambda: [
    ("qwen-flash", {"name": "Qwen3.8-Flash"}, "cn"),
    ("claude-sonnet", {"name": "Claude-Sonnet"}, "intl"),
]
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), P.Handler)
PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

try:
    status, view = request("GET", "/settings", panel=TOKEN)
    check("settings API returns per-key models and notes without clear-text keys",
          status == 200 and view["api_keys"][0]["models"] == ["qwen3.8-flash"]
          and view["api_keys"][0]["note"] == "keep this note"
          and "key" not in view["api_keys"][0], view)

    status, reply = models("flash-secret")
    check("Flash key sees its configured model by display name",
          status == 200 and [m["id"] for m in reply["data"]] == ["Qwen3.8-Flash"], reply)
    status, reply = models("claude-secret")
    check("another key sees a different, independent model set",
          status == 200 and [m["id"] for m in reply["data"]] == ["Claude-Sonnet"], reply)
    status, reply = models("open-secret")
    check("empty model list preserves unrestricted discovery",
          status == 200 and len(reply["data"]) == 2, reply)
    status, reply = request("GET", "/v1/models?merge_realms=1", key="flash-secret")
    check("merged model discovery is filtered by the same key",
          status == 200 and len(reply["data"]) == 1
          and reply["data"][0]["id"] == "Qwen3.8-Flash", reply)
    reused = keepalive_models()
    check("keep-alive does not leak one key restrictions into the next request",
          len(reused[0]["data"]) == 1 and len(reused[1]["data"]) == 2,
          [[m["id"] for m in reply["data"]] for reply in reused])

    for path in ("/v1/chat/completions", "/v1/responses", "/v1/messages"):
        status, reply, calls = inference(path, "Claude-Sonnet", "flash-secret")
        check("%s rejects a model outside this key before upstream" % path,
              status == 400 and "模型限制" in str(reply) and calls == 0, reply)
    status, reply, calls = inference("/v1/chat/completions", "Qwen3.8-Flash", "flash-secret")
    check("allowed model reaches the upstream boundary", calls == 1, (status, reply))
    status, reply, calls = inference("/v1/chat/completions", "Claude-Sonnet", "claude-secret")
    check("the same model is allowed with the other key", calls == 1, (status, reply))

    os.environ["QD_WEB_TOOLS"] = "on"
    try:
        status, reply, calls = inference("/v1/chat/completions", "Claude-Sonnet",
                                          "flash-secret", tools=True)
        check("web-tools branch cannot bypass the key allowlist",
              status == 400 and "模型限制" in str(reply) and calls == 0, reply)
    finally:
        os.environ.pop("QD_WEB_TOOLS", None)

    status, reply = save_keys([
        {"id": "flash", "key": "", "name": "Renamed", "realm": "", "enabled": True},
        {"id": "claude", "key": "", "name": "Claude only", "realm": "", "enabled": True},
        {"id": "open", "key": "", "name": "Unrestricted", "realm": "", "enabled": True},
    ])
    stored = S.api_keys(D)
    check("legacy panel payload preserves stored models and notes",
          status == 200 and stored[0]["models"] == ["qwen3.8-flash"]
          and stored[0]["note"] == "keep this note"
          and stored[1]["models"] == ["claude-*"], stored)
    status, reply = save_keys([
        {"id": "flash", "key": "", "name": "Flash only", "realm": "", "enabled": True,
         "models": [], "note": "keep this note"},
    ])
    check("explicitly clearing a key model list restores unrestricted access",
          status == 200 and S.api_keys(D)[0]["models"] == []
          and S.api_keys(D)[0]["note"] == "keep this note", S.api_keys(D))
finally:
    srv.shutdown()
    srv.server_close()
    for name, value in old.items():
        setattr(P, name, value)
    shutil.rmtree(D, ignore_errors=True)

finish()
