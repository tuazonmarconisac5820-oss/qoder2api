# -*- coding: utf-8 -*-
"""多租户（BYOA）端到端测试：注册 / 登录 / Key 隔离 / 账号隔离 / 公共池兜底 / 模型闸门。

在子进程里通过 QD_MULTIUSER_DB 环境变量启用多租户模式，验证：
  1. 注册（首个用户自动成为管理员）+ 重复用户名拒绝
  2. 登录拿 Token + Token 验证 + 错误密码拒绝
  3. API Key 创建（明文只返回一次）+ hash 存储 + 识别
  4. 账号按用户隔离（A 看不到 B 的私有账号）
  5. 公共账号池兜底（所有用户可见）
  6. 每 Key 模型白名单闸门（/v1/models 过滤 + 推理前置拒绝）
  7. 用量按用户归属写入 SQLite
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _suite_head import *        # noqa: F401,F403

import tempfile
import threading
import http.server
import http.client

declare_suite(__file__, ["qoder_proxy.py", "qoder_db.py", "qoder_auth.py",
                         "qoder_crypto.py", "qoder_user_pool.py"])

_DB_DIR = tempfile.mkdtemp(prefix="qd-mt-")
_DB_PATH = os.path.join(_DB_DIR, "multiuser.db")

# 关键：必须在 bootstrap() 导入 qoder_proxy 之前注入环境变量
P, A = bootstrap(env={"QD_MULTIUSER_DB": _DB_PATH})

import qoder_db
import qoder_auth
import qoder_user_pool

# 隔离全局状态（多租户模式下 POOL 基本不用，但避免旧账号干扰）
P.ACCOUNTS_DIR = _DB_DIR
P.API_KEY = ""
P.API_KEY_FILE_SET = False
P.POOL = None
outbound = []


def fake_upstream(payload, **kwargs):
    outbound.append({"payload": dict(payload), "kwargs": kwargs})
    raise RuntimeError("multiuser test: request reached upstream")


P.open_upstream = fake_upstream
P.fetch_models = lambda realm=None: [
    ("qwen-flash", {"name": "Qwen3.8-Flash", "aliases": ["Qwen-Flash"]}),
    ("claude-sonnet", {"name": "Claude-Sonnet"}),
]


def request(method, path, body=None, key=None, token=None):
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=15)
    headers = {}
    if key:
        headers["Authorization"] = "Bearer " + key
    if token:
        headers["X-Panel-Token"] = token
    raw = None
    if body is not None:
        raw = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    try:
        conn.request(method, path, body=raw, headers=headers)
        response = conn.getresponse()
        text = response.read().decode("utf-8", "replace")
        try:
            return response.status, json.loads(text)
        except ValueError:
            return response.status, text
    finally:
        conn.close()


srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), P.Handler)
PORT = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()

try:
    # ── 1. 注册 ──────────────────────────────────────────────────────────────
    status, r = request("POST", "/api/register",
                        {"username": "alice", "password": "pass1234"})
    check("注册：首个用户成功且自动成为管理员",
          status == 200 and r.get("ok") and r.get("is_admin") is True, r)

    status, r = request("POST", "/api/register",
                        {"username": "bob", "password": "pass1234"})
    check("注册：第二个用户成功且不是管理员",
          status == 200 and r.get("ok") and r.get("is_admin") is False, r)

    status, r = request("POST", "/api/register",
                        {"username": "alice", "password": "whatever123"})
    check("注册：重复用户名被拒绝", status == 400 and "已被占用" in str(r), r)

    status, r = request("POST", "/api/register",
                        {"username": "x", "password": "pass1234"})
    check("注册：非法用户名被拒绝", status == 400, r)

    # ── 2. 登录 ──────────────────────────────────────────────────────────────
    status, login = request("POST", "/api/login",
                            {"username": "alice", "password": "pass1234"})
    check("登录：成功返回 Token", status == 200 and login.get("ok")
          and len(login.get("token", "")) > 20, login)
    alice_token = login.get("token", "")

    status, r = request("POST", "/api/login",
                        {"username": "alice", "password": "wrongpass"})
    check("登录：错误密码被拒绝", status == 401, r)

    status, r = request("POST", "/api/login",
                        {"username": "bob", "password": "pass1234"})
    bob_token = r.get("token", "")

    # ── 3. Token 验证 ────────────────────────────────────────────────────────
    status, me = request("GET", "/api/me", token=alice_token)
    check("Token 验证：/api/me 返回用户身份",
          status == 200 and me.get("username") == "alice"
          and me.get("is_admin") is True, me)

    status, r = request("GET", "/api/me", token="invalid-token")
    check("Token 验证：无效 Token 被拒绝", status == 401, r)

    # ── 4. API Key ───────────────────────────────────────────────────────────
    status, key = request("POST", "/api/keys",
                          {"name": "alice-key", "models": ["Qwen3.8-Flash"]},
                          token=alice_token)
    check("创建 Key：返回明文且格式正确",
          status == 200 and key.get("key", "").startswith("qd-")
          and "key_hash" not in key, key)
    alice_key = key.get("key", "")

    # Key 已存 DB 且为 hash
    rows = qoder_db.list_api_keys()
    check("Key 存储：数据库只存 hash 不存明文",
          len(rows) == 1 and "key_hash" in rows[0]
          and "key" not in rows[0]
          and rows[0]["key_hash"] == qoder_db.sha256_hex(alice_key),
          [k for k in rows[0].keys()])

    # 明文识别
    rec = qoder_auth.identify_api_key(alice_key)
    check("Key 识别：明文可定位记录", rec is not None
          and rec["models"] == ["Qwen3.8-Flash"], rec)

    # ── 5. 账号隔离 ──────────────────────────────────────────────────────────
    qoder_user_pool.add_account_from_oauth(me["user_id"], {
        "uid": "alice-uid-1", "realm": "cn",
        "accessToken": "alice-access-token",
        "nickname": "Alice 的账号",
        "source": "oauth",
    })
    # bob 也加一个
    status, bob_me = request("GET", "/api/me", token=bob_token)
    qoder_user_pool.add_account_from_oauth(bob_me["user_id"], {
        "uid": "bob-uid-1", "realm": "cn",
        "accessToken": "bob-access-token",
        "nickname": "Bob 的账号",
        "source": "oauth",
    })

    status, accounts = request("GET", "/api/accounts", token=alice_token)
    check("账号隔离：Alice 只看得到自己的账号",
          status == 200 and len(accounts["accounts"]) == 1
          and accounts["accounts"][0]["uid"] == "alice-uid-1", accounts)

    status, accounts = request("GET", "/api/accounts", token=bob_token)
    check("账号隔离：Bob 只看得到自己的账号",
          status == 200 and len(accounts["accounts"]) == 1
          and accounts["accounts"][0]["uid"] == "bob-uid-1", accounts)

    # ── 6. 公共池兜底 ────────────────────────────────────────────────────────
    qoder_user_pool.add_account_from_oauth(None, {
        "uid": "public-uid-1", "realm": "cn",
        "accessToken": "public-access-token",
        "nickname": "公共账号",
        "source": "oauth",
    })
    status, accounts = request("GET", "/api/accounts", token=alice_token)
    check("公共池兜底：Alice 能看到自己的 + 公共账号",
          status == 200 and len(accounts["accounts"]) == 2
          and any(a["source"] == "public" for a in accounts["accounts"]),
          accounts)

    # ── 7. 模型闸门（每 Key 白名单）───────────────────────────────────────────
    status, models = request("GET", "/v1/models", key=alice_key)
    check("/v1/models 按 Key 过滤：只返回白名单内的模型",
          status == 200 and [m["id"] for m in models["data"]] == ["Qwen3.8-Flash"],
          models)

    # 请求白名单外的模型 → 本地 400，不碰上游
    before = len(outbound)
    status, r = request("POST", "/v1/chat/completions",
                        {"model": "Claude-Sonnet",
                         "messages": [{"role": "user", "content": "hi"}]},
                        key=alice_key)
    check("推理前置拒绝：白名单外模型返回 400 且未达上游",
          status == 400 and "模型限制" in str(r)
          and len(outbound) == before, r)

    # 请求白名单内的模型 → 通过闸门（无账号池，应到上游或被选号失败拦截）
    status, r = request("POST", "/v1/chat/completions",
                        {"model": "Qwen3.8-Flash",
                         "messages": [{"role": "user", "content": "hi"}]},
                        key=alice_key)
    check("白名单内模型通过闸门（本测试无真实上游，应报 5xx/上游错误而非 400 模型限制）",
          status != 400, (status, r))

    # ── 8. 无 Key 访问 /v1 被拒绝（多租户模式强制鉴权）────────────────────────
    status, r = request("GET", "/v1/models")
    check("多租户模式：无 Key 访问 /v1 被拒绝", status == 401, r)

    # ── 9. 用量归属 ──────────────────────────────────────────────────────────
    s = qoder_db.usage_summary(me["user_id"])
    # 注意：fake_upstream 抛异常，可能没有成功写入用量；这里验证 API 存在即可
    status, summary = request("GET", "/api/usage", token=alice_token)
    check("用量 API：按用户返回汇总", status == 200
          and "requests" in summary, summary)

    # ── 10. 管理员视图 ───────────────────────────────────────────────────────
    status, r = request("GET", "/api/admin/users", token=alice_token)
    check("管理员：可查看所有用户", status == 200
          and len(r.get("users", [])) == 2, r)

    status, r = request("GET", "/api/admin/users", token=bob_token)
    check("非管理员：不能查看用户列表", status == 404 or status == 401, r)

    status, r = request("GET", "/api/admin/accounts", token=alice_token)
    check("管理员：可查看所有账号（含归属）", status == 200
          and len(r.get("accounts", [])) == 3, r)

    # ── 管理员一键签到全站账号 ──
    status, r = request("POST", "/api/admin/accounts/checkin", {"uid": "all"}, token=bob_token)
    check("非管理员：不能调用管理员全站签到接口", status in (404, 401, 403), r)

    status, r = request("POST", "/api/admin/accounts/checkin", {"uid": "all"}, token=alice_token)
    check("管理员：一键签到全站账号返回成功", status == 200 and r.get("ok") is True
          and "total" in r and "results" in r, r)

    status, r = request("POST", "/api/admin/accounts/checkin", {"uid": "alice-uid-1"}, token=alice_token)
    check("管理员：单独为指定账号签到返回成功", status == 200 and r.get("ok") is True
          and len(r.get("results", [])) == 1, r)

    # ── 11. 删除 Key / 删除账号（REST DELETE）─────────────────────────────────
    status, key2 = request("POST", "/api/keys",
                           {"name": "to-delete"}, token=alice_token)
    kid = key2.get("id", "")
    status, r = request("DELETE", "/api/keys/" + kid, body={}, token=alice_token)
    check("删除 Key：DELETE 返回 ok", status == 200 and r.get("ok") is True, r)
    status, keys = request("GET", "/api/keys", token=alice_token)
    remaining_ids = [k["id"] for k in keys.get("keys", [])]
    check("删除 Key：删除后不再出现在列表", kid not in remaining_ids, remaining_ids)

    # 越权删除：bob 不能删 alice 的 key
    status, key3 = request("POST", "/api/keys",
                           {"name": "alice-keep"}, token=alice_token)
    status, r = request("DELETE", "/api/keys/" + key3["id"], body={}, token=bob_token)
    check("越权防护：bob 不能删除 alice 的 key",
          status == 200 and r.get("ok") is False, r)

    # 删除账号
    status, r = request("DELETE", "/api/accounts/bob-uid-1", body={}, token=bob_token)
    check("删除账号：DELETE 返回 ok", status == 200 and r.get("ok") is True, r)
    status, accounts = request("GET", "/api/accounts", token=bob_token)
    uids = [a["uid"] for a in accounts.get("accounts", [])]
    check("删除账号：删除后不再出现在列表（仅剩公共池）",
          "bob-uid-1" not in uids, uids)

finally:
    srv.shutdown()
    srv.server_close()

finish()
