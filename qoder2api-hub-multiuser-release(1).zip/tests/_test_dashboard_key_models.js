/* Per-key model editing: parse, display, save, and failure propagation. */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ROOT = path.join(__dirname, '..');
const html = fs.readFileSync(path.join(ROOT, 'dashboard.html'), 'utf8');
let PASS = 0, FAIL = 0;
function check(name, ok){ if(ok){ PASS++; console.log('  [PASS] ' + name); } else { FAIL++; console.log('  [FAIL] ' + name); } }
function slice(from, to){
  const a = html.indexOf(from), b = html.indexOf(to, a);
  if(a < 0 || b < 0) throw new Error('missing script anchors: ' + from);
  return html.slice(a, b);
}
const source = slice('/* ---- API key list:', '/* ---- 事实性限额护栏');
const esc = s => String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const els = {};
const document = {getElementById(id){ return els[id] || (els[id] = {id, value:'', disabled:false, innerHTML:'', textContent:'', focus(){}}); }};
const window = {crypto: null};
const posted = [];
const toasts = [];
let failSave = false;
let loadCount = 0;
const api = new Function('document', 'window', 'esc', 'toast', 'postJSON', 'loadSettings', 'confirm',
  source + '\nreturn {API_KEY_ROWS, keyModelPatterns, keyModelSummary, renderKeyRows, saveSingleKey, saveApiKeys, addApiKeyRow};')(
  document, window, esc, (m, k) => toasts.push(k + ':' + m),
  async (url, body) => { posted.push({url, body}); if(failSave) throw new Error('disk full'); return {ok:true}; },
  async () => { loadCount++; }, () => true);

check('model patterns support comma, semicolon and newline with deduplication',
  JSON.stringify(api.keyModelPatterns(' Qwen*, Claude-Sonnet;Qwen*\n')) === JSON.stringify(['Qwen*', 'Claude-Sonnet']));
check('empty model input explicitly means unrestricted', api.keyModelSummary([]) === '全部模型（不限制）');
check('configured model summary is visible outside edit mode', api.keyModelSummary(['Qwen*']) === 'Qwen*');
api.API_KEY_ROWS.push({id:'k1', name:'团队 A', key:'', masked:'sk-1******cret', realm:'', models:['Qwen3.8-Flash', 'Claude*'], note:'<safe>', enabled:true, created_at:''});
api.renderKeyRows();
check('collapsed key card displays its own model list and escapes note HTML',
  els.keyList.innerHTML.includes('Qwen3.8-Flash、Claude*') && els.keyList.innerHTML.includes('&lt;safe&gt;'));
api.API_KEY_ROWS[0]._editing = true;
api.renderKeyRows();
check('edit form includes one independent model textarea per key',
  els.keyList.innerHTML.includes('editKeyModels_0') && els.keyList.innerHTML.includes('Qwen3.8-Flash\nClaude*') && els.keyList.innerHTML.includes('留空 = 不限制'));
['editKeyName_0', 'editKeyRealm_0', 'editKeyValue_0', 'editKeyNote_0', 'editKeyModels_0'].forEach(document.getElementById);
els.editKeyName_0.value = '团队 A';
els.editKeyRealm_0.value = '';
els.editKeyValue_0.value = '';
els.editKeyNote_0.value = '<safe>';
els.editKeyModels_0.value = ' Qwen3.8-Max\nQwen3.8-Max, Claude-Sonnet ';
api.saveSingleKey(0, els.saveButton || (els.saveButton = {disabled:false})).then(async () => {
  check('single-key save submits only that key model configuration',
    posted.length === 1 && JSON.stringify(posted[0].body.api_keys[0].models) === JSON.stringify(['Qwen3.8-Max', 'Claude-Sonnet']));
  check('single-key save keeps the blank secret unchanged', posted[0].body.api_keys[0].key === '');
  check('successful save refreshes persisted settings', loadCount === 1 && els.saveButton.disabled === false);
  failSave = true;
  toasts.length = 0;
  let propagated = false;
  try { await api.saveApiKeys(); } catch(e){ propagated = e.message === 'disk full'; }
  check('save failure propagates to callers instead of a false success', propagated);
  check('failed save produces only error toasts, never a success toast',
    toasts.some(x => x.startsWith('bad:')) && !toasts.some(x => x.startsWith('ok:')));
  check('model input is wired into key editing, not just a static label', source.includes('row.models = models;'));
  console.log('SUITE: ' + path.basename(__filename) + ' md5=' + crypto.createHash('md5').update(fs.readFileSync(__filename)).digest('hex'));
  console.log('FILE: dashboard.html md5=' + crypto.createHash('md5').update(html).digest('hex') + ' bytes=' + Buffer.byteLength(html) + ' as-of=' + new Date().toISOString());
  console.log('SUMMARY: TOTAL ' + (PASS + FAIL) + ' checks, ' + PASS + ' passed, ' + FAIL + ' failed');
  console.log('RESULT: ' + (FAIL ? 'RED' : 'GREEN') + ' (exit ' + (FAIL ? 1 : 0) + ')');
  process.exit(FAIL ? 1 : 0);
}).catch(e => { console.error(e); process.exit(1); });
