-- qoder2api-hub 多租户数据库 schema
-- SQLite 3.x，启用 WAL 模式以支持并发读写

PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

-- ── 用户表 ──────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id            TEXT PRIMARY KEY,          -- uuid4
    username      TEXT UNIQUE NOT NULL,      -- 3-32位 字母数字下划线
    password_hash TEXT NOT NULL,             -- PBKDF2-SHA256 hex
    password_salt TEXT NOT NULL,             -- 32字节 hex
    is_admin      INTEGER NOT NULL DEFAULT 0,
    enabled       INTEGER NOT NULL DEFAULT 1,
    created_at    TEXT NOT NULL              -- ISO-8601 UTC
);

-- ── Qoder 账号表 ─────────────────────────────────────────────────────────────
-- user_id IS NULL  →  公共账号池（管理员维护）
-- user_id NOT NULL →  用户私有账号
CREATE TABLE IF NOT EXISTS qoder_accounts (
    uid              TEXT PRIMARY KEY,       -- Qoder 设备 UID
    user_id          TEXT,                   -- NULL = 公共池
    realm            TEXT NOT NULL,          -- cn / intl
    access_token_enc TEXT NOT NULL,          -- AES-256-GCM 加密后的 accessToken
    refresh_token_enc  TEXT NOT NULL DEFAULT '',
    personal_token_enc TEXT NOT NULL DEFAULT '',
    nickname         TEXT NOT NULL DEFAULT '',
    note             TEXT NOT NULL DEFAULT '',
    enabled          INTEGER NOT NULL DEFAULT 1,
    credits          REAL,
    plan             TEXT NOT NULL DEFAULT '',
    expires_at       REAL,                   -- Unix epoch
    last_checkin     TEXT NOT NULL DEFAULT '',
    source           TEXT NOT NULL DEFAULT 'oauth',
    created_at       TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_qa_user  ON qoder_accounts(user_id);
CREATE INDEX IF NOT EXISTS idx_qa_realm ON qoder_accounts(realm);

-- ── API Key 表 ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS api_keys (
    id          TEXT PRIMARY KEY,
    user_id     TEXT NOT NULL,
    name        TEXT NOT NULL DEFAULT '',
    key_hash    TEXT NOT NULL,               -- SHA-256(plaintext)，十六进制
    models      TEXT NOT NULL DEFAULT '[]',  -- JSON 数组
    realm       TEXT NOT NULL DEFAULT '',
    enabled     INTEGER NOT NULL DEFAULT 1,
    note        TEXT NOT NULL DEFAULT '',
    created_at  TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ak_hash ON api_keys(key_hash);
CREATE INDEX  IF NOT EXISTS idx_ak_user ON api_keys(user_id);

-- ── 用量日志 ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS usage_log (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id           TEXT NOT NULL,
    api_key_id        TEXT,
    account_uid       TEXT,
    account_source    TEXT NOT NULL DEFAULT 'private',
    model             TEXT NOT NULL DEFAULT '',
    realm             TEXT NOT NULL DEFAULT '',
    prompt_tokens     INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    reasoning_tokens  INTEGER NOT NULL DEFAULT 0,
    cached_tokens     INTEGER NOT NULL DEFAULT 0,
    credits           REAL    NOT NULL DEFAULT 0,
    original_credits  REAL    NOT NULL DEFAULT 0,
    stream            INTEGER NOT NULL DEFAULT 0,
    elapsed_ms        INTEGER,
    ttft_ms           INTEGER,
    created_at        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ul_user ON usage_log(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_ul_key  ON usage_log(api_key_id);

-- ── 面板会话 ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS panel_sessions (
    token_hash  TEXT PRIMARY KEY,
    user_id     TEXT NOT NULL,
    expires_at  TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ── 注册/登录限流 ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS register_attempts (
    ip           TEXT NOT NULL,
    attempted_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_ra_ip ON register_attempts(ip, attempted_at);

CREATE TABLE IF NOT EXISTS login_failures (
    ip        TEXT NOT NULL,
    username  TEXT NOT NULL DEFAULT '',
    failed_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_lf_ip ON login_failures(ip, failed_at);
