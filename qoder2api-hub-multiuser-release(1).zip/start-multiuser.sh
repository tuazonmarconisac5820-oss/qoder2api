#!/usr/bin/env bash
# ===========================================================
#  Qoder2API-Hub 多租户增强版一键启动脚本 (Linux / macOS)
#  默认启用 SQLite 独立数据库与多租户隔离体系
# ===========================================================
PORT="${1:-8790}"
HERE="$(cd -- "$(dirname -- "$0")" && pwd)"

# 默认多租户数据库位置
export QD_MULTIUSER_DB="${QD_MULTIUSER_DB:-$HERE/data/multiuser.db}"
mkdir -p "$(dirname "$QD_MULTIUSER_DB")"

echo "==========================================================="
echo "  Qoder2API-Hub (多租户增强版)"
echo "  数据库文件 : $QD_MULTIUSER_DB"
echo "  服务端口   : $PORT"
echo "  控制面板   : http://127.0.0.1:$PORT/"
echo "  API 接入点 : http://127.0.0.1:$PORT/v1"
echo "==========================================================="

PIDFILE="$HERE/qoder-proxy.pid"
exec python3 "$HERE/qoder_proxy.py" --port "$PORT" --pid-file "$PIDFILE"
