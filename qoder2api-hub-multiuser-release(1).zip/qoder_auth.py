"""qoder_auth.py — 用户注册、登录、Token 鉴权

仅依赖标准库 + qoder_db。
"""
import hashlib
import hmac
import json
import os
import re
import secrets
import time

import qoder_db

# ── 常量 ─────────────────────────────────────────────────────────────────────

PBKDF2_ROUNDS   = 120_000
USERNAME_RE     = re.compile(r"^[a-zA-Z0-9_]{3,32}$")
PASSWORD_MIN    = 6
TOKEN_TTL       = 7 * 24 * 3600   # 7天，与 panel_session 一致
API_KEY_PREFIX  = "qd-"
API_KEY_BYTES   = 24               # 生成 48 字符 hex，加前缀共 51 字符


# ── 密码工具 ─────────────────────────────────────────────────────────────────

def hash_password(password: str, salt: str | None = None) -> tuple[str, str]:
    """返回 (hash_hex, salt_hex)。"""
    if salt is None:
        salt = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt), PBKDF2_ROUNDS
    ).hex()
    return digest, salt


def verify_password(password: str, stored_hash: str, stored_salt: str) -> bool:
    try:
        computed, _ = hash_password(password, stored_salt)
        return hmac.compare_digest(computed, stored_hash)
    except Exception:
        return False


# ── 注册 ─────────────────────────────────────────────────────────────────────

class AuthError(Exception):
    """status_code 属性指定 HTTP 状态码。"""
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status


def register(username: str, password: str, client_ip: str = "") -> dict:
    """
    注册新用户。成功返回 {"ok": True, "user_id": "..."}。
    失败抛 AuthError。
    """
    username = (username or "").strip()
    password = (password or "")

    # 速率限制
    if client_ip and not qoder_db.check_register_rate(client_ip):
        raise AuthError("注册过于频繁，请稍后再试", 429)

    # 用户名校验
    if not USERNAME_RE.match(username):
        raise AuthError("用户名只允许字母、数字、下划线，长度 3-32 位")

    # 密码校验
    if len(password) < PASSWORD_MIN:
        raise AuthError(f"密码至少 {PASSWORD_MIN} 位")

    # 重名检查
    if qoder_db.get_user_by_username(username):
        raise AuthError("用户名已被占用")

    # 第一个注册的用户自动成为管理员
    is_admin = (qoder_db.count_users() == 0)

    ph, salt = hash_password(password)
    user = qoder_db.create_user(username, ph, salt, is_admin=is_admin)

    if client_ip:
        qoder_db.record_register_attempt(client_ip)

    return {"ok": True, "user_id": user["id"], "is_admin": is_admin}


# ── 登录 ─────────────────────────────────────────────────────────────────────

def login(username: str, password: str, client_ip: str = "") -> dict:
    """
    登录，成功返回 {"ok": True, "token": "...", "user_id": "...", "is_admin": ...}。
    失败抛 AuthError。
    """
    username = (username or "").strip()

    # 速率限制
    if client_ip and not qoder_db.check_login_rate(client_ip):
        raise AuthError("登录失败次数过多，请 10 分钟后再试", 429)

    user = qoder_db.get_user_by_username(username)
    if not user or not user.get("enabled"):
        if client_ip:
            qoder_db.record_login_failure(client_ip, username)
        raise AuthError("用户名或密码错误", 401)

    if not verify_password(password, user["password_hash"], user["password_salt"]):
        if client_ip:
            qoder_db.record_login_failure(client_ip, username)
        raise AuthError("用户名或密码错误", 401)

    # 登录成功，清除失败记录
    if client_ip:
        qoder_db.clear_login_failures(client_ip)

    token = _generate_token(user["id"])
    qoder_db.create_panel_session(user["id"], token)

    return {
        "ok": True,
        "token": token,
        "user_id": user["id"],
        "username": user["username"],
        "is_admin": bool(user["is_admin"]),
    }


def logout(token: str) -> None:
    qoder_db.revoke_panel_session(token)


# ── Token 验证 ────────────────────────────────────────────────────────────────

def verify_panel_token(token: str) -> dict | None:
    """
    验证面板 Token，返回用户信息 dict 或 None。
    """
    if not token:
        return None
    return qoder_db.validate_panel_session(token)


def _generate_token(user_id: str) -> str:
    """生成不可伪造的面板 Token（随机字节 + user_id 绑定）。"""
    rand = secrets.token_hex(24)
    # token = rand:user_id:hmac
    msg = f"{rand}:{user_id}".encode()
    secret = _token_secret()
    sig = hmac.new(secret, msg, hashlib.sha256).hexdigest()
    return f"{rand}:{user_id}:{sig}"


def _token_secret() -> bytes:
    """从环境变量或固定派生获取 Token 签名密钥（与加密密钥独立）。"""
    env = os.environ.get("QD_TOKEN_SECRET", "").strip()
    if env:
        try:
            raw = bytes.fromhex(env)
            if len(raw) >= 16:
                # 派生独立的签名密钥，避免与加密密钥复用
                return hashlib.sha256(b"auth-sign:" + raw).digest()
        except ValueError:
            pass
    return hashlib.sha256(b"qoder-auth-sign-fallback").digest()


# ── API Key 管理 ──────────────────────────────────────────────────────────────

def generate_api_key() -> str:
    """生成随机 API Key，格式 qd-<48字符hex>。"""
    return API_KEY_PREFIX + secrets.token_hex(API_KEY_BYTES)


def create_api_key(user_id: str, name: str,
                   models: list | None = None,
                   realm: str = "",
                   note: str = "") -> dict:
    """
    创建 API Key，返回包含明文 key 的 dict（明文只在此返回一次）。
    """
    plaintext = generate_api_key()
    key_hash = qoder_db.sha256_hex(plaintext)
    record = qoder_db.create_api_key(
        user_id=user_id,
        name=name or "未命名",
        key_hash=key_hash,
        models=models or [],
        realm=realm,
        note=note,
    )
    return {
        "id":         record["id"],
        "name":       record["name"],
        "key":        plaintext,      # 明文，仅此一次
        "models":     models or [],
        "realm":      realm,
        "note":       note,
        "created_at": record["created_at"],
    }


def identify_api_key(plaintext: str) -> dict | None:
    """
    根据明文 API Key 查找 Key 记录，返回 dict 或 None。
    """
    if not plaintext:
        return None
    key_hash = qoder_db.sha256_hex(plaintext)
    record = qoder_db.get_api_key_by_hash(key_hash)
    if not record:
        return None
    # 解析 models JSON
    try:
        record["models"] = json.loads(record.get("models") or "[]")
    except Exception:
        record["models"] = []
    return record


# ── 密码修改 ─────────────────────────────────────────────────────────────────

def change_password(user_id: str, current_password: str,
                    new_password: str) -> None:
    user = qoder_db.get_user_by_id(user_id)
    if not user:
        raise AuthError("用户不存在", 404)
    if not verify_password(current_password, user["password_hash"],
                           user["password_salt"]):
        raise AuthError("当前密码错误", 401)
    if len(new_password) < PASSWORD_MIN:
        raise AuthError(f"新密码至少 {PASSWORD_MIN} 位")
    ph, salt = hash_password(new_password)
    qoder_db.update_user(user_id, password_hash=ph, password_salt=salt)
    qoder_db.revoke_all_sessions(user_id)
