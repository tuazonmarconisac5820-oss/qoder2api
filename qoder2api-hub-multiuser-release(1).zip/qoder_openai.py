"""qoder_openai.py — OpenAI 账号与 OAuth 设备授权处理模块

提供：
1. 内置代理配置（支持代码内默认代理、OPENAI_PROXY 环境变量、系统代理、或前端自定义代理）
2. OpenAI 官方 Device Code Flow（OAuth 设备授权流）发起与轮询换取 Access Token
3. OpenAI 官方 API 代理中继（Chat Completions 流式与非流式透传）
4. 支持自定义 OPENAI_API_BASE（支持中继站/反向代理反代域名）
"""
import os
import json
import time
import uuid
import threading
import urllib.request
import urllib.parse
import urllib.error

# ---------------------------------------------------------------------------
# 代理与端点配置（可在源码内预设默认代理，也可通过环境变量重写）
# ---------------------------------------------------------------------------
# 1. 源码内置代理地址（若环境有固定代理，可直接填在此处，如 "http://127.0.0.1:7890"）
BUILTIN_PROXY = os.environ.get("OPENAI_PROXY") or os.environ.get("QD_OPENAI_PROXY") or ""

# 2. OpenAI 官方 OAuth 与 API 端点
OPENAI_OAUTH_AUTH_URL = "https://auth0.openai.com/oauth/device/code"
OPENAI_OAUTH_TOKEN_URL = "https://auth0.openai.com/oauth/token"
OPENAI_CLIENT_ID = "pdlLIX2Y72MIlIKLKKjRiK2magcfweKc"

# 可配置自定义 API 基础地址（支持各类第三方免翻中继或自建反代）
OPENAI_API_BASE = os.environ.get("OPENAI_BASE_URL") or os.environ.get("OPENAI_API_BASE") or "https://api.openai.com/v1"

_login_lock = threading.Lock()
_openai_logins = {}   # state -> dict


def _build_opener(custom_proxy: str = None):
    """
    构造支持代理的 urllib opener。
    优先级：显式传入的 proxy > OPENAI_PROXY 环境变量 > 源码 BUILTIN_PROXY > 系统 HTTP_PROXY/HTTPS_PROXY
    """
    proxy = (custom_proxy or "").strip() or BUILTIN_PROXY or \
            os.environ.get("HTTPS_PROXY") or os.environ.get("HTTP_PROXY") or \
            os.environ.get("https_proxy") or os.environ.get("http_proxy")
    if proxy:
        proxy_handler = urllib.request.ProxyHandler({'http': proxy, 'https': proxy})
        return urllib.request.build_opener(proxy_handler)
    return urllib.request.build_opener()


def start_openai_login(proxy: str = None) -> dict:
    """发起 OpenAI OAuth Device Code 授权。返回 {status, state, authUrl, userCode, expiresIn}。"""
    data = urllib.parse.urlencode({
        "client_id": OPENAI_CLIENT_ID,
        "scope": "openid profile email model.request offline_access",
    }).encode("utf-8")
    
    req = urllib.request.Request(
        OPENAI_OAUTH_AUTH_URL,
        data=data,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
            "User-Agent": "OpenAI/v1 Node/v18 (OpenAI-Codex-Device-Flow)",
        },
        method="POST"
    )
    
    opener = _build_opener(proxy)
    try:
        with opener.open(req, timeout=15) as resp:
            res = json.loads(resp.read().decode("utf-8"))
            device_code = res.get("device_code")
            user_code = res.get("user_code")
            verification_uri = res.get("verification_uri") or res.get("verification_uri_complete") or "https://openai.com/device"
            interval = int(res.get("interval") or 5)
            expires_in = int(res.get("expires_in") or 900)
    except urllib.error.HTTPError as exc:
        if exc.code == 403:
            raise RuntimeError("OpenAI Auth0 拒绝访问 (HTTP 403 Forbidden)。"
                               "检测到直连被 Cloudflare 拦截，请在上方输入代理地址（如 http://127.0.0.1:7890）或在源码中配置内置代理。")
        raise RuntimeError("发起 OpenAI 授权失败: HTTP Error %s: %s" % (exc.code, exc.reason))
    except Exception as exc:
        raise RuntimeError("发起 OpenAI 授权失败: %s" % exc)

    state = "oa-" + uuid.uuid4().hex[:16]
    with _login_lock:
        _openai_logins[state] = {
            "created": time.time(),
            "device_code": device_code,
            "user_code": user_code,
            "interval": interval,
            "expires_in": expires_in,
            "proxy": proxy or BUILTIN_PROXY,
        }
        
    return {
        "status": "ok",
        "state": state,
        "authUrl": verification_uri,
        "userCode": user_code,
        "expiresIn": expires_in,
    }


def poll_openai_login(state: str) -> dict:
    """轮询 OpenAI 设备授权状态。成功时返回 account 字典。"""
    with _login_lock:
        info = _openai_logins.get(state)
    if not info:
        return {"status": "unknown", "message": "授权状态已失效，请重新发起"}
    
    if time.time() - info["created"] > info["expires_in"]:
        with _login_lock:
            _openai_logins.pop(state, None)
        return {"status": "expired", "message": "授权已过期，请重新发起"}
    
    data = urllib.parse.urlencode({
        "client_id": OPENAI_CLIENT_ID,
        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
        "device_code": info["device_code"],
    }).encode("utf-8")
    
    req = urllib.request.Request(
        OPENAI_OAUTH_TOKEN_URL,
        data=data,
        headers={
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
            "User-Agent": "OpenAI/v1 Node/v18",
        },
        method="POST"
    )
    
    opener = _build_opener(info.get("proxy"))
    try:
        with opener.open(req, timeout=15) as resp:
            token_res = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", "replace")
        try:
            err_obj = json.loads(body)
            err_code = err_obj.get("error")
        except Exception:
            err_code = ""
        if err_code == "authorization_pending":
            return {"status": "pending", "message": "等待浏览器完成 OpenAI 账号授权（验证码：%s）" % info["user_code"]}
        if err_code == "slow_down":
            return {"status": "pending", "message": "频率控制中，请稍候…"}
        return {"status": "error", "message": "OpenAI 授权错误: %s" % (err_obj.get("error_description") or err_code or body[:120])}
    except Exception as exc:
        return {"status": "pending", "message": "正在连接 OpenAI: %s" % exc}
        
    access_token = token_res.get("access_token") or ""
    refresh_token = token_res.get("refresh_token") or ""
    if not access_token:
        return {"status": "pending", "message": "等待令牌生成…"}
        
    uid = "oa-" + uuid.uuid4().hex[:12]
    nickname = "OpenAI 官方账号"
    try:
        me_req = urllib.request.Request(
            f"{OPENAI_API_BASE.rstrip('/')}/me",
            headers={"Authorization": "Bearer " + access_token, "User-Agent": "OpenAI/v1"}
        )
        with opener.open(me_req, timeout=10) as me_resp:
            me_data = json.loads(me_resp.read().decode("utf-8"))
            if me_data.get("id"):
                uid = "oa-" + str(me_data["id"])[:12]
            if me_data.get("name") or me_data.get("email"):
                nickname = me_data.get("name") or me_data.get("email")
    except Exception:
        pass
        
    with _login_lock:
        _openai_logins.pop(state, None)
        
    account_doc = {
        "uid": uid,
        "nickname": nickname,
        "realm": "openai",
        "domain": urllib.parse.urlparse(OPENAI_API_BASE).netloc or "api.openai.com",
        "accessToken": access_token,
        "refreshToken": refresh_token,
        "source": "openai_oauth",
        "enabled": True,
        "expiresAt": int(time.time()) + int(token_res.get("expires_in") or 3600 * 24 * 30),
    }
    return {"status": "ok", "account": account_doc}


def forward_openai_chat(payload: dict, access_token: str, stream: bool = False, proxy: str = None):
    """直接代理请求到官方 OpenAI API 或中继 API。"""
    url = f"{OPENAI_API_BASE.rstrip('/')}/chat/completions"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream" if stream else "application/json",
            "User-Agent": "OpenAI-Gateway/1.0",
        },
        method="POST"
    )
    opener = _build_opener(proxy)
    return opener.open(req, timeout=60)
