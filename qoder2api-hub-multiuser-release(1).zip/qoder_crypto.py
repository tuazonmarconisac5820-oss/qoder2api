"""qoder_crypto.py — AES-256-GCM Token 加密（纯标准库实现）

密钥来源（按优先级）：
  1. 环境变量 QD_TOKEN_SECRET（32字节 hex，64字符）
  2. 自动生成并持久化到 data/token_secret.key（仅限单机部署）

加密格式（base64 编码后存库）：
  nonce(12B) || ciphertext || tag(16B)
"""
import base64
import hashlib
import hmac
import os
import struct
import threading

_key_lock = threading.Lock()
_cached_key: bytes | None = None

# ── 密钥管理 ─────────────────────────────────────────────────────────────────

def _load_or_generate_key(key_file: str) -> bytes:
    """从文件读取密钥，文件不存在时生成并保存。"""
    try:
        data = open(key_file, "rb").read().strip()
        if len(data) == 64:          # hex 编码
            return bytes.fromhex(data.decode("ascii"))
        if len(data) == 32:          # 原始字节
            return data
    except (FileNotFoundError, ValueError):
        pass
    # 生成新密钥
    key = os.urandom(32)
    os.makedirs(os.path.dirname(key_file) or ".", exist_ok=True)
    with open(key_file, "wb") as fh:
        fh.write(key.hex().encode())
    return key


def get_key(key_file: str = "") -> bytes:
    """返回 32 字节加密密钥（全局缓存，线程安全）。"""
    global _cached_key
    with _key_lock:
        if _cached_key is not None:
            return _cached_key
        env = os.environ.get("QD_TOKEN_SECRET", "").strip()
        if env:
            try:
                raw = bytes.fromhex(env)
                if len(raw) == 32:
                    _cached_key = raw
                    return _cached_key
            except ValueError:
                pass
        if not key_file:
            key_file = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                "data", "token_secret.key"
            )
        _cached_key = _load_or_generate_key(key_file)
        return _cached_key


def reset_key_cache() -> None:
    """测试用：清除缓存的密钥。"""
    global _cached_key
    with _key_lock:
        _cached_key = None


# ── AES-256-GCM（纯 Python 实现） ────────────────────────────────────────────
# 复用项目已有的 qoder_sign.py 中的 AES 实现，避免引入第三方库。
# 这里重新封装成独立的 GCM 实现，确保不依赖 qoder_sign 的内部细节。

def _xor_bytes(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))


# ──── AES-128/256 key schedule（来自 qoder_sign.py 同款纯 Python AES）────────
_SBOX = [
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
]

_RCON = [0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36]

def _sub_word(w):
    return (_SBOX[w>>24] <<24 | _SBOX[(w>>16)&0xff] <<16
            | _SBOX[(w>>8)&0xff] <<8 | _SBOX[w&0xff])

def _rot_word(w):
    return ((w & 0x00ffffff) << 8) | (w >> 24)

def _key_expansion(key: bytes) -> list[int]:
    nk = len(key) // 4
    nr = nk + 6
    w = list(struct.unpack(f">{nk}I", key))
    for i in range(nk, 4*(nr+1)):
        temp = w[i-1]
        if i % nk == 0:
            temp = _sub_word(_rot_word(temp)) ^ (_RCON[i//nk-1] << 24)
        elif nk > 6 and i % nk == 4:
            temp = _sub_word(temp)
        w.append(w[i-nk] ^ temp)
    return w


def _gmul(a: int, b: int) -> int:
    p = 0
    for _ in range(8):
        if b & 1:
            p ^= a
        hi = a & 0x80
        a = (a << 1) & 0xff
        if hi:
            a ^= 0x1b
        b >>= 1
    return p


def _mix_col(s: list[int]) -> list[int]:
    return [
        _gmul(s[0],2)^_gmul(s[1],3)^s[2]^s[3],
        s[0]^_gmul(s[1],2)^_gmul(s[2],3)^s[3],
        s[0]^s[1]^_gmul(s[2],2)^_gmul(s[3],3),
        _gmul(s[0],3)^s[1]^s[2]^_gmul(s[3],2),
    ]


def _aes_encrypt_block(block: bytes, round_keys: list[int]) -> bytes:
    """加密单个 16 字节块（ECB 单块）。"""
    state = list(block)
    nr = len(round_keys)//4 - 1

    def add_round_key(r):
        for i in range(4):
            rk = round_keys[r*4+i]
            for j in range(4):
                state[j*4+i] ^= (rk >> (24-8*j)) & 0xff

    def sub_bytes():
        for i in range(16):
            state[i] = _SBOX[state[i]]

    def shift_rows():
        for r in range(1, 4):
            row = [state[r + 4*c] for c in range(4)]
            row = row[r:] + row[:r]
            for c in range(4):
                state[r + 4*c] = row[c]

    def mix_columns():
        for c in range(4):
            col = [state[r*4+c] for r in range(4)]
            mc = _mix_col(col)
            for r in range(4):
                state[r*4+c] = mc[r]

    add_round_key(0)
    for rnd in range(1, nr):
        sub_bytes(); shift_rows(); mix_columns(); add_round_key(rnd)
    sub_bytes(); shift_rows(); add_round_key(nr)
    return bytes(state)


def _aes_ctr_keystream(key: bytes, nonce: bytes, counter: int, length: int) -> bytes:
    """生成 AES-CTR 密钥流（用于 GCM 加密步骤）。"""
    rk = _key_expansion(key)
    stream = bytearray()
    while len(stream) < length:
        block = nonce + struct.pack(">I", counter)
        stream += _aes_encrypt_block(block, rk)
        counter += 1
    return bytes(stream[:length])


# ──── GCM GHASH ──────────────────────────────────────────────────────────────

def _gcm_ghash(h_block: bytes, data: bytes) -> bytes:
    """计算 GHASH（GCM 认证）。"""
    def _ghash_mul(x: bytes, y: bytes) -> bytes:
        z = 0
        v = int.from_bytes(y, "big")
        x_int = int.from_bytes(x, "big")
        for i in range(128):
            if (x_int >> (127-i)) & 1:
                z ^= v
            if v & 1:
                v = (v >> 1) ^ 0xe1000000000000000000000000000000
            else:
                v >>= 1
        return z.to_bytes(16, "big")

    h = h_block
    y = b"\x00" * 16
    for i in range(0, len(data), 16):
        block = data[i:i+16].ljust(16, b"\x00")
        y = _ghash_mul(bytes(a^b for a,b in zip(y, block)), h)
    return y


def _aes_gcm_encrypt(key: bytes, nonce: bytes, plaintext: bytes,
                     aad: bytes = b"") -> tuple[bytes, bytes]:
    """AES-GCM 加密，返回 (ciphertext, tag)。"""
    rk = _key_expansion(key)
    # H = AES(K, 0^128)
    h_block = _aes_encrypt_block(b"\x00" * 16, rk)
    # E(K, J0)
    j0 = nonce + b"\x00\x00\x00\x01"
    ek_j0 = _aes_encrypt_block(j0, rk)
    # CTR 加密（counter 从 2 开始）
    ks = _aes_ctr_keystream(key, nonce, 2, len(plaintext))
    ct = bytes(a^b for a,b in zip(plaintext, ks))
    # GHASH
    pad = lambda x: x + b"\x00"*((-len(x))%16)
    ghash_in = (pad(aad)
                + pad(ct)
                + struct.pack(">Q", len(aad)*8)
                + struct.pack(">Q", len(ct)*8))
    s = _gcm_ghash(h_block, ghash_in)
    tag = bytes(a^b for a,b in zip(s, ek_j0))
    return ct, tag


def _aes_gcm_decrypt(key: bytes, nonce: bytes, ciphertext: bytes,
                     tag: bytes, aad: bytes = b"") -> bytes:
    """AES-GCM 解密，tag 验证失败时抛 ValueError。"""
    rk = _key_expansion(key)
    h_block = _aes_encrypt_block(b"\x00" * 16, rk)
    j0 = nonce + b"\x00\x00\x00\x01"
    ek_j0 = _aes_encrypt_block(j0, rk)
    pad = lambda x: x + b"\x00"*((-len(x))%16)
    ghash_in = (pad(aad)
                + pad(ciphertext)
                + struct.pack(">Q", len(aad)*8)
                + struct.pack(">Q", len(ciphertext)*8))
    s = _gcm_ghash(h_block, ghash_in)
    expected_tag = bytes(a^b for a,b in zip(s, ek_j0))
    if not hmac.compare_digest(tag, expected_tag):
        raise ValueError("GCM tag verification failed")
    ks = _aes_ctr_keystream(key, nonce, 2, len(ciphertext))
    return bytes(a^b for a,b in zip(ciphertext, ks))


# ── 公开接口 ─────────────────────────────────────────────────────────────────

def encrypt_token(plaintext: str, key_file: str = "") -> str:
    """加密 Qoder Token，返回 base64 字符串（nonce||ciphertext||tag）。"""
    if not plaintext:
        return ""
    key = get_key(key_file)
    nonce = os.urandom(12)
    ct, tag = _aes_gcm_encrypt(key, nonce, plaintext.encode("utf-8"))
    raw = nonce + ct + tag
    return base64.b64encode(raw).decode("ascii")


def decrypt_token(encoded: str, key_file: str = "") -> str:
    """解密 base64 编码的 Token，验证失败返回空字符串。"""
    if not encoded:
        return ""
    try:
        key = get_key(key_file)
        raw = base64.b64decode(encoded)
        nonce, ct, tag = raw[:12], raw[12:-16], raw[-16:]
        return _aes_gcm_decrypt(key, nonce, ct, tag).decode("utf-8")
    except Exception:
        return ""
