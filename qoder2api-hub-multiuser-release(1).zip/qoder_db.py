"""qoder_db.py — SQLite 数据库层（多租户模式）

只用标准库：sqlite3。WAL 模式支持多线程并发读写。
所有函数无状态，通过 get_db() 获取连接（每线程独立连接）。
"""
import hashlib
import json
import os
import sqlite3
import threading
import time
import uuid
from pathlib import Path

_local = threading.local()
_db_path: str = ""
_init_lock = threading.Lock()
_initialized = False

SCHEMA_SQL = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema.sql")

# ── 初始化 ───────────────────────────────────────────────────────────────────

def init(db_path: str) -> None:
    """初始化数据库路径并建表（仅执行一次）。"""
    global _db_path, _initialized
    with _init_lock:
        if _initialized and _db_path == db_path:
            return
        _db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        conn = _connect(db_path)
        _apply_schema(conn)
        conn.close()
        _initialized = True


def _connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, check_same_thread=False, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA synchronous=NORMAL")
    return conn


def _apply_schema(conn: sqlite3.Connection) -> None:
    try:
        with open(SCHEMA_SQL, encoding="utf-8") as fh:
            sql = fh.read()
    except FileNotFoundError:
        sql = _INLINE_SCHEMA
    # 逐条执行（跳过 PRAGMA 语句，已在连接时设置）
    for stmt in sql.split(";"):
        stmt = stmt.strip()
        if stmt and not stmt.upper().startswith("PRAGMA"):
            try:
                conn.execute(stmt)
            except sqlite3.OperationalError:
                pass
    conn.commit()


def get_db() -> sqlite3.Connection:
    """返回当前线程的数据库连接（惰性创建）。"""
    conn = getattr(_local, "conn", None)
    if conn is None:
        if not _db_path:
            raise RuntimeError("qoder_db.init() 必须在使用前调用")
        _local.conn = _connect(_db_path)
        conn = _local.conn
    return conn


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _uuid() -> str:
    return str(uuid.uuid4())


# ── 工具函数 ─────────────────────────────────────────────────────────────────

def sha256_hex(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# ── 用户 CRUD ────────────────────────────────────────────────────────────────

def create_user(username: str, password_hash: str, password_salt: str,
                is_admin: bool = False) -> dict:
    uid = _uuid()
    db = get_db()
    db.execute(
        "INSERT INTO users(id,username,password_hash,password_salt,is_admin,enabled,created_at)"
        " VALUES(?,?,?,?,?,1,?)",
        (uid, username, password_hash, password_salt, 1 if is_admin else 0, _now_iso())
    )
    db.commit()
    return get_user_by_id(uid)


def get_user_by_id(uid: str) -> dict | None:
    row = get_db().execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    return dict(row) if row else None


def get_user_by_username(username: str) -> dict | None:
    row = get_db().execute(
        "SELECT * FROM users WHERE username=?", (username,)
    ).fetchone()
    return dict(row) if row else None


def list_users(enabled_only: bool = False) -> list[dict]:
    sql = "SELECT * FROM users"
    if enabled_only:
        sql += " WHERE enabled=1"
    sql += " ORDER BY created_at"
    return [dict(r) for r in get_db().execute(sql).fetchall()]


def update_user(uid: str, **kwargs) -> None:
    allowed = {"password_hash", "password_salt", "is_admin", "enabled"}
    fields = {k: v for k, v in kwargs.items() if k in allowed}
    if not fields:
        return
    sets = ", ".join(f"{k}=?" for k in fields)
    get_db().execute(f"UPDATE users SET {sets} WHERE id=?",
                     (*fields.values(), uid))
    get_db().commit()


def count_users() -> int:
    return get_db().execute("SELECT COUNT(*) FROM users").fetchone()[0]


# ── Qoder 账号 CRUD ──────────────────────────────────────────────────────────

def upsert_qoder_account(uid: str, user_id: str | None, realm: str,
                         access_token_enc: str,
                         refresh_token_enc: str = "",
                         personal_token_enc: str = "",
                         nickname: str = "",
                         note: str = "",
                         source: str = "oauth",
                         credits: float | None = None,
                         plan: str = "",
                         expires_at: float | None = None) -> dict:
    db = get_db()
    now = _now_iso()
    if isinstance(credits, dict):
        credits = credits.get("remain_effective") if credits.get("remain_effective") is not None else credits.get("remain")
    if credits is not None:
        try:
            credits = float(credits)
        except (ValueError, TypeError):
            credits = None
    existing = db.execute(
        "SELECT uid FROM qoder_accounts WHERE uid=?", (uid,)
    ).fetchone()
    if existing:
        db.execute(
            """UPDATE qoder_accounts SET
               user_id=?, realm=?, access_token_enc=?,
               refresh_token_enc=?, personal_token_enc=?,
               nickname=?, note=?, source=?,
               credits=COALESCE(?,credits),
               plan=COALESCE(NULLIF(?,''),(SELECT plan FROM qoder_accounts WHERE uid=?)),
               expires_at=COALESCE(?,expires_at)
               WHERE uid=?""",
            (user_id, realm, access_token_enc,
             refresh_token_enc, personal_token_enc,
             nickname, note, source,
             credits, plan, uid, expires_at, uid)
        )
    else:
        db.execute(
            """INSERT INTO qoder_accounts
               (uid,user_id,realm,access_token_enc,refresh_token_enc,
                personal_token_enc,nickname,note,enabled,credits,plan,
                expires_at,source,created_at)
               VALUES(?,?,?,?,?,?,?,?,1,?,?,?,?,?)""",
            (uid, user_id, realm, access_token_enc, refresh_token_enc,
             personal_token_enc, nickname, note, credits, plan,
             expires_at, source, now)
        )
    db.commit()
    return get_qoder_account(uid)


def get_qoder_account(uid: str) -> dict | None:
    row = get_db().execute(
        "SELECT * FROM qoder_accounts WHERE uid=?", (uid,)
    ).fetchone()
    return dict(row) if row else None


def list_qoder_accounts(user_id: str | None = "NOFILTER",
                        realm: str | None = None,
                        enabled_only: bool = False,
                        include_public: bool = False) -> list[dict]:
    """
    user_id="NOFILTER" → 全部（管理员视图）
    user_id=None       → 只取公共池
    user_id="xxx"      → 该用户私有账号
    include_public=True → user_id账号 + 公共池
    """
    conditions = []
    params = []
    if user_id != "NOFILTER":
        if include_public:
            conditions.append("(user_id=? OR user_id IS NULL)")
            params.append(user_id)
        elif user_id is None:
            conditions.append("user_id IS NULL")
        else:
            conditions.append("user_id=?")
            params.append(user_id)
    if realm:
        conditions.append("realm=?")
        params.append(realm)
    if enabled_only:
        conditions.append("enabled=1")
    sql = "SELECT * FROM qoder_accounts"
    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    sql += " ORDER BY created_at"
    return [dict(r) for r in get_db().execute(sql, params).fetchall()]


def update_qoder_account(uid: str, **kwargs) -> None:
    allowed = {"enabled", "note", "nickname", "credits", "plan",
               "expires_at", "last_checkin", "access_token_enc",
               "refresh_token_enc", "personal_token_enc", "user_id"}
    fields = {k: v for k, v in kwargs.items() if k in allowed}
    if not fields:
        return
    if "credits" in fields:
        c = fields["credits"]
        if isinstance(c, dict):
            c = c.get("remain_effective") if c.get("remain_effective") is not None else c.get("remain")
        try:
            fields["credits"] = float(c) if c is not None else None
        except (ValueError, TypeError):
            fields["credits"] = None
    sets = ", ".join(f"{k}=?" for k in fields)
    get_db().execute(f"UPDATE qoder_accounts SET {sets} WHERE uid=?",
                     (*fields.values(), uid))
    get_db().commit()


def delete_qoder_account(uid: str) -> bool:
    db = get_db()
    cur = db.execute("DELETE FROM qoder_accounts WHERE uid=?", (uid,))
    db.commit()
    return cur.rowcount > 0


# ── API Key CRUD ─────────────────────────────────────────────────────────────

def create_api_key(user_id: str, name: str, key_hash: str,
                   models: list | None = None,
                   realm: str = "", note: str = "") -> dict:
    kid = _uuid()
    db = get_db()
    db.execute(
        """INSERT INTO api_keys(id,user_id,name,key_hash,models,realm,enabled,note,created_at)
           VALUES(?,?,?,?,?,?,1,?,?)""",
        (kid, user_id, name, key_hash,
         json.dumps(models or [], ensure_ascii=False),
         realm, note, _now_iso())
    )
    db.commit()
    return get_api_key_by_id(kid)


def get_api_key_by_hash(key_hash: str) -> dict | None:
    row = get_db().execute(
        "SELECT * FROM api_keys WHERE key_hash=? AND enabled=1", (key_hash,)
    ).fetchone()
    return dict(row) if row else None


def get_api_key_by_id(kid: str) -> dict | None:
    row = get_db().execute("SELECT * FROM api_keys WHERE id=?", (kid,)).fetchone()
    return dict(row) if row else None


def list_api_keys(user_id: str | None = None) -> list[dict]:
    if user_id:
        rows = get_db().execute(
            "SELECT * FROM api_keys WHERE user_id=? ORDER BY created_at",
            (user_id,)
        ).fetchall()
    else:
        rows = get_db().execute(
            "SELECT * FROM api_keys ORDER BY created_at"
        ).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        try:
            d["models"] = json.loads(d.get("models") or "[]")
        except Exception:
            d["models"] = []
        result.append(d)
    return result


def update_api_key(kid: str, user_id: str, **kwargs) -> bool:
    """只允许修改 user_id 下自己的 Key（防越权）。"""
    allowed = {"name", "models", "realm", "enabled", "note"}
    fields = {}
    for k, v in kwargs.items():
        if k not in allowed:
            continue
        if k == "models":
            v = json.dumps(v if isinstance(v, list) else [], ensure_ascii=False)
        fields[k] = v
    if not fields:
        return False
    sets = ", ".join(f"{k}=?" for k in fields)
    cur = get_db().execute(
        f"UPDATE api_keys SET {sets} WHERE id=? AND user_id=?",
        (*fields.values(), kid, user_id)
    )
    get_db().commit()
    return cur.rowcount > 0


def delete_api_key(kid: str, user_id: str) -> bool:
    cur = get_db().execute(
        "DELETE FROM api_keys WHERE id=? AND user_id=?", (kid, user_id)
    )
    get_db().commit()
    return cur.rowcount > 0


# ── 用量日志 ─────────────────────────────────────────────────────────────────

def insert_usage(user_id: str, model: str, realm: str,
                 prompt_tokens: int = 0, completion_tokens: int = 0,
                 reasoning_tokens: int = 0, cached_tokens: int = 0,
                 credits: float = 0, original_credits: float = 0,
                 stream: bool = False, elapsed_ms: int | None = None,
                 ttft_ms: int | None = None,
                 api_key_id: str | None = None,
                 account_uid: str | None = None,
                 account_source: str = "private") -> int:
    db = get_db()
    cur = db.execute(
        """INSERT INTO usage_log
           (user_id,api_key_id,account_uid,account_source,model,realm,
            prompt_tokens,completion_tokens,reasoning_tokens,cached_tokens,
            credits,original_credits,stream,elapsed_ms,ttft_ms,created_at)
           VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (user_id, api_key_id, account_uid, account_source, model, realm,
         prompt_tokens, completion_tokens, reasoning_tokens, cached_tokens,
         credits, original_credits, 1 if stream else 0,
         elapsed_ms, ttft_ms, _now_iso())
    )
    db.commit()
    return cur.lastrowid


def usage_summary(user_id: str | None = None,
                  since_iso: str | None = None,
                  until_iso: str | None = None) -> dict:
    conditions = []
    params = []
    if user_id:
        conditions.append("user_id=?")
        params.append(user_id)
    if since_iso:
        conditions.append("created_at>=?")
        params.append(since_iso)
    if until_iso:
        conditions.append("created_at<?")
        params.append(until_iso)
    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    row = get_db().execute(
        f"""SELECT COUNT(*) AS requests,
                   SUM(prompt_tokens) AS prompt_tokens,
                   SUM(completion_tokens) AS completion_tokens,
                   SUM(credits) AS credits
            FROM usage_log {where}""",
        params
    ).fetchone()
    pub_today = user_public_credits_today(user_id) if user_id else 0.0
    return {
        "requests":             row["requests"] or 0,
        "prompt_tokens":        row["prompt_tokens"] or 0,
        "completion_tokens":    row["completion_tokens"] or 0,
        "credits":              round(float(row["credits"] or 0), 4),
        "public_credits_today": pub_today,
    }


def user_public_credits_today(user_id: str) -> float:
    """查询指定用户在当天（本地日期 YYYY-MM-DD）从公共池消耗的 Credits 总和。"""
    today_start = time.strftime("%Y-%m-%d 00:00:00")
    row = get_db().execute(
        """SELECT COALESCE(SUM(credits), 0.0) AS total_credits
           FROM usage_log
           WHERE user_id=? AND account_source='public' AND created_at>=?""",
        (user_id, today_start)
    ).fetchone()
    return round(float(row["total_credits"]), 4) if row else 0.0


def recent_usage_rows(user_id: str | None = None, limit: int = 100,
                      page: int = 1) -> list[dict]:
    offset = (page - 1) * limit
    if user_id:
        rows = get_db().execute(
            "SELECT * FROM usage_log WHERE user_id=?"
            " ORDER BY id DESC LIMIT ? OFFSET ?",
            (user_id, limit, offset)
        ).fetchall()
    else:
        rows = get_db().execute(
            "SELECT * FROM usage_log ORDER BY id DESC LIMIT ? OFFSET ?",
            (limit, offset)
        ).fetchall()
    return [dict(r) for r in rows]


# ── 面板会话 ─────────────────────────────────────────────────────────────────

SESSION_TTL = 7 * 24 * 3600   # 7 天


def create_panel_session(user_id: str, token: str) -> None:
    th = sha256_hex(token)
    exp = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ",
        time.gmtime(time.time() + SESSION_TTL)
    )
    db = get_db()
    db.execute(
        "INSERT OR REPLACE INTO panel_sessions(token_hash,user_id,expires_at)"
        " VALUES(?,?,?)",
        (th, user_id, exp)
    )
    db.commit()


def validate_panel_session(token: str) -> dict | None:
    """验证 Token 并返回用户信息，过期或不存在返回 None。"""
    th = sha256_hex(token)
    row = get_db().execute(
        "SELECT ps.user_id, ps.expires_at, u.username, u.is_admin, u.enabled"
        " FROM panel_sessions ps JOIN users u ON ps.user_id=u.id"
        " WHERE ps.token_hash=?",
        (th,)
    ).fetchone()
    if not row:
        return None
    now_iso = _now_iso()
    if row["expires_at"] < now_iso:
        get_db().execute("DELETE FROM panel_sessions WHERE token_hash=?", (th,))
        get_db().commit()
        return None
    if not row["enabled"]:
        return None
    return dict(row)


def revoke_panel_session(token: str) -> None:
    th = sha256_hex(token)
    get_db().execute("DELETE FROM panel_sessions WHERE token_hash=?", (th,))
    get_db().commit()


def revoke_all_sessions(user_id: str) -> None:
    get_db().execute("DELETE FROM panel_sessions WHERE user_id=?", (user_id,))
    get_db().commit()


# ── 注册/登录限流 ────────────────────────────────────────────────────────────

REGISTER_WINDOW  = 3600    # 1小时内
REGISTER_MAX     = 5       # 最多注册 5 次
LOGIN_WINDOW     = 600     # 10分钟内
LOGIN_FAIL_MAX   = 10      # 最多失败 10 次


def _cleanup_old(table: str, col: str, window: int) -> None:
    cutoff = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ",
        time.gmtime(time.time() - window)
    )
    get_db().execute(f"DELETE FROM {table} WHERE {col}<?", (cutoff,))


def check_register_rate(ip: str) -> bool:
    """True = 允许注册，False = 超限。"""
    _cleanup_old("register_attempts", "attempted_at", REGISTER_WINDOW)
    cutoff = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ",
        time.gmtime(time.time() - REGISTER_WINDOW)
    )
    n = get_db().execute(
        "SELECT COUNT(*) FROM register_attempts WHERE ip=? AND attempted_at>=?",
        (ip, cutoff)
    ).fetchone()[0]
    return n < REGISTER_MAX


def record_register_attempt(ip: str) -> None:
    get_db().execute(
        "INSERT INTO register_attempts(ip,attempted_at) VALUES(?,?)",
        (ip, _now_iso())
    )
    get_db().commit()


def check_login_rate(ip: str) -> bool:
    """True = 允许登录，False = 暂时锁定。"""
    _cleanup_old("login_failures", "failed_at", LOGIN_WINDOW)
    cutoff = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ",
        time.gmtime(time.time() - LOGIN_WINDOW)
    )
    n = get_db().execute(
        "SELECT COUNT(*) FROM login_failures WHERE ip=? AND failed_at>=?",
        (ip, cutoff)
    ).fetchone()[0]
    return n < LOGIN_FAIL_MAX


def record_login_failure(ip: str, username: str = "") -> None:
    get_db().execute(
        "INSERT INTO login_failures(ip,username,failed_at) VALUES(?,?,?)",
        (ip, username, _now_iso())
    )
    get_db().commit()


def clear_login_failures(ip: str) -> None:
    get_db().execute("DELETE FROM login_failures WHERE ip=?", (ip,))
    get_db().commit()


# ── 内联 Schema（备用，schema.sql 丢失时） ──────────────────────────────────
_INLINE_SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL, password_salt TEXT NOT NULL,
    is_admin INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS qoder_accounts (
    uid TEXT PRIMARY KEY, user_id TEXT,
    realm TEXT NOT NULL, access_token_enc TEXT NOT NULL,
    refresh_token_enc TEXT NOT NULL DEFAULT '',
    personal_token_enc TEXT NOT NULL DEFAULT '',
    nickname TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 1, credits REAL, plan TEXT NOT NULL DEFAULT '',
    expires_at REAL, last_checkin TEXT NOT NULL DEFAULT '',
    source TEXT NOT NULL DEFAULT 'oauth', created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_qa_user ON qoder_accounts(user_id);
CREATE TABLE IF NOT EXISTS api_keys (
    id TEXT PRIMARY KEY, user_id TEXT NOT NULL, name TEXT NOT NULL DEFAULT '',
    key_hash TEXT NOT NULL, models TEXT NOT NULL DEFAULT '[]',
    realm TEXT NOT NULL DEFAULT '', enabled INTEGER NOT NULL DEFAULT 1,
    note TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE UNIQUE INDEX IF NOT EXISTS idx_ak_hash ON api_keys(key_hash);
CREATE INDEX IF NOT EXISTS idx_ak_user ON api_keys(user_id);
CREATE TABLE IF NOT EXISTS usage_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT NOT NULL,
    api_key_id TEXT, account_uid TEXT,
    account_source TEXT NOT NULL DEFAULT 'private',
    model TEXT NOT NULL DEFAULT '', realm TEXT NOT NULL DEFAULT '',
    prompt_tokens INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    reasoning_tokens INTEGER NOT NULL DEFAULT 0,
    cached_tokens INTEGER NOT NULL DEFAULT 0,
    credits REAL NOT NULL DEFAULT 0, original_credits REAL NOT NULL DEFAULT 0,
    stream INTEGER NOT NULL DEFAULT 0, elapsed_ms INTEGER, ttft_ms INTEGER,
    created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_ul_user ON usage_log(user_id, created_at);
CREATE TABLE IF NOT EXISTS panel_sessions (
    token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, expires_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS register_attempts (
    ip TEXT NOT NULL, attempted_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_ra_ip ON register_attempts(ip, attempted_at);
CREATE TABLE IF NOT EXISTS login_failures (
    ip TEXT NOT NULL, username TEXT NOT NULL DEFAULT '', failed_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_lf_ip ON login_failures(ip, failed_at);
"""
